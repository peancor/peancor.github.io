﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilTetris
{
    public class TetradFactory
    {
        readonly static Random mRandom = new Random();

        public static Tetrad CreateRandom()
        {
            TetradType type = (TetradType)mRandom.Next(1, 8);
            return Create((TetradType)type);
        }

        public static Tetrad Create(TetradType type)
        {
            switch (type)
            {
                case TetradType.I:
                    return new ITetrad();
                case TetradType.J:
                    return new JTetrad();
                case TetradType.L:
                    return new LTetrad();
                case TetradType.O:
                    return new OTetrad();
                case TetradType.S:
                    return new STetrad();
                case TetradType.T:
                    return new TTetrad();
                case TetradType.Z:
                    return new ZTetrad();
                default:
                    throw new InvalidOperationException();
            }
        }        
    }
}
