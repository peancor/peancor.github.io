﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace SilTetris
{
    public class PlayField : Canvas
    {
        Size mTetradSize;

        public PlayField()
        {
            SizeChanged += new SizeChangedEventHandler(PlayField_SizeChanged);
            App.Model.Updated += new Action(Update);
            
        }

        void PlayField_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Reset();
        }

        void Reset()
        {
            mTetradSize = new Size(ActualWidth / Model.Width, ActualHeight / Model.Height);
            this.Children.Clear();
            for (int y = 0; y < Model.Height; y++)
            {
                for (int x = 0; x < Model.Width; x++)
                {
                    BlockControl block = new BlockControl() { Width = mTetradSize.Width, Height = mTetradSize.Height };
                    Canvas.SetLeft(block, mTetradSize.Width * x);
                    Canvas.SetTop(block, mTetradSize.Height * y);
                    Children.Add(block);
                }
            }
            Update();
        }

        BlockControl GetBlockControl(int x, int y)
        {
            Debug.Assert(x >= 0 && x < Model.Width && y >= 0 && y < Model.Height);
            return (BlockControl)Children[y * Model.Width + x];
        }

        void Update()
        {
            for (int y = 0; y < Model.Height; y++)
            {
                for (int x = 0; x < Model.Width; x++)
                {
                    BlockControl bc = GetBlockControl(x, y);
                    if (App.Model[x, y] == TetradType.None)
                        bc.Visibility = Visibility.Collapsed;
                    else
                    {
                        bc.BlockFill = BrushFactory.GetBrush(App.Model[x, y]);
                        bc.Visibility = Visibility.Visible;
                    }
                }
            }
        }
    }
}
