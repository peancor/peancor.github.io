﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;
using System.Diagnostics;

namespace SilTetris
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();

            Loaded += new RoutedEventHandler(Page_Loaded);
            KeyDown += new KeyEventHandler(Page_KeyDown);
            App.Model.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(Model_PropertyChanged);
            App.Model.LineCompleted += new Action(Model_LineCompleted);
            App.Model.LevelUp += new Action(Model_LevelUp);
        }



        void Model_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case "GameState":
                    switch (App.Model.GameState)
                    {
                        case GameState.GameOver:
                            mPlayFieldGrid.Visibility = Visibility.Collapsed;
                            mGameOverGrid.Visibility = Visibility.Visible;
                            break;
                    }
                    break;
            }
        }

        void Model_LineCompleted()
        {
            mLineCompletedSoundMediaElement.Position = TimeSpan.Zero;
            mLineCompletedSoundMediaElement.Play();
        }

        void Model_LevelUp()
        {
            mLevelUpSoundMediaElement.Position = TimeSpan.Zero;
            mLevelUpSoundMediaElement.Play();
        }

        void Page_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        void Page_KeyDown(object sender, KeyEventArgs e)
        {
            App.Model.KeyDown(e.Key);
        }

        private void mClickToPlayButton_Click(object sender, RoutedEventArgs e)
        {
            Debug.Assert(App.Model.GameState == GameState.Start);
            mStartScreenGrid.Visibility = Visibility.Collapsed;
            mPlayFieldGrid.Visibility = Visibility.Visible;
            App.Model.StartGame();
        }

        private void mClickToReplayButton_Click(object sender, RoutedEventArgs e)
        {
            Debug.Assert(App.Model.GameState == GameState.GameOver);
            mPlayFieldGrid.Visibility = Visibility.Visible;
            mGameOverGrid.Visibility = Visibility.Collapsed;
            App.Model.StartGame();
        }
    }
}
