﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilTetris
{
    public class BrushFactory
    {
        static SolidColorBrush mBrushI = new SolidColorBrush(Colors.Red);
        static SolidColorBrush mBrushJ = new SolidColorBrush(Colors.Yellow);
        static SolidColorBrush mBrushL = new SolidColorBrush(Colors.Magenta);
        static SolidColorBrush mBrushO = new SolidColorBrush(Colors.Blue);
        static SolidColorBrush mBrushS = new SolidColorBrush(Colors.Cyan);
        static SolidColorBrush mBrushT = new SolidColorBrush(Colors.Green);
        static SolidColorBrush mBrushZ = new SolidColorBrush(Colors.Orange);


        public static Brush GetBrush(TetradType type)
        {
            switch (type)
            {
                case TetradType.I:
                    return mBrushI;
                case TetradType.J:
                    return mBrushJ;
                case TetradType.L:
                    return mBrushL;
                case TetradType.O:
                    return mBrushO;
                case TetradType.S:
                    return mBrushS;
                case TetradType.T:
                    return mBrushT;
                case TetradType.Z:
                    return mBrushZ;
                default:
                    throw new InvalidOperationException();
            }
        }        
    }
}
