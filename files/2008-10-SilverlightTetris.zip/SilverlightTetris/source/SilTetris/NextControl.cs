﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace SilTetris
{
    public class NextControl : Canvas
    {
        Size mBlockSize;
        const int GridWidth = 4;
        const int GridHeight = 2;

        public static readonly DependencyProperty TetradProperty = DependencyProperty.Register(
            "Tetrad", typeof(Tetrad), typeof(NextControl), new PropertyMetadata(OnPropertyChanged));

        public Tetrad Tetrad
        {
            get { return (Tetrad)GetValue(TetradProperty); }
            set { SetValue(TetradProperty, value); }
        }

        public NextControl()
        {
            Loaded += new RoutedEventHandler(NextControl_Loaded);
            SizeChanged += new SizeChangedEventHandler(NextControl_SizeChanged);
        }

        void NextControl_Loaded(object sender, RoutedEventArgs e)
        {
            Reset();
        }

        void NextControl_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Reset();
        }

        void Reset()
        {
            mBlockSize = new Size(ActualWidth / GridWidth, ActualHeight / GridHeight);
            this.Children.Clear();
            for (int y = 0; y < GridHeight; y++)
            {
                for (int x = 0; x < GridWidth; x++)
                {
                    BlockControl block = new BlockControl() { Width = mBlockSize.Width, Height = mBlockSize.Height };
                    Canvas.SetLeft(block, mBlockSize.Width * x);
                    Canvas.SetTop(block, mBlockSize.Height * y);
                    Children.Add(block);
                    if (Tetrad != null && Tetrad[x, y] != TetradType.None)
                    {
                        block.BlockFill = BrushFactory.GetBrush(Tetrad[x, y]);
                        block.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        block.Visibility = Visibility.Collapsed;
                    }
                }
            }
        }

        BlockControl GetBlockControl(int x, int y)
        {
            return (BlockControl)Children[y * GridWidth + x];
        }

        static void OnPropertyChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            NextControl nc = (NextControl)o;
            nc.Reset();
        }
    }
}
