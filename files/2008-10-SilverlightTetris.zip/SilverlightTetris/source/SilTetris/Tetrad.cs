﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace SilTetris
{
    public enum TetradType
    {
        None = 0,
        I = 1,
        J = 2,
        L = 3,
        O = 4,
        S = 5,
        T = 6,
        Z = 7
    }

    public abstract class Tetrad
    {
        public const Int32 Width = 4;
        public const Int32 Height = 4;
        protected readonly List<TetradType[,]> mBlocks = new List<TetradType[,]>();
        Int32 mBlockIndex = 0;

        public void RotateForward()
        {
            mBlockIndex++;
            if (mBlockIndex>=mBlocks.Count) mBlockIndex = 0;
        }

        public void RotateBackward()
        {
            mBlockIndex--;
            if (mBlockIndex < 0) mBlockIndex = mBlocks.Count - 1;
        }

        public TetradType this[Int32 x, Int32 y]
        {
            get {return mBlocks[mBlockIndex][x,y];}
        }
     }

    public class ITetrad : Tetrad
    {
        public ITetrad()
        {
            TetradType[,] block = new TetradType[Width, Height];
            block[0, 0] = block[1, 0] = block[2, 0] = block[3, 0] = TetradType.I;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[0, 0] = block[0, 1] = block[0, 2] = block[0, 3] = TetradType.I;
            mBlocks.Add(block);
        }
    }

    public class JTetrad: Tetrad
    {
        public JTetrad()
        {
            TetradType[,] block = new TetradType[Width, Height];
            block[0, 0] = block[1, 0] = block[2, 0] = block[2, 1] = TetradType.J;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[0, 0] = block[1, 0] = block[0, 1] = block[0, 2] = TetradType.J;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[0, 0] = block[0, 1] = block[1, 1] = block[2, 1] = TetradType.J;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[0, 2] = block[1, 0] = block[1, 1] = block[1, 2] = TetradType.J;
            mBlocks.Add(block);
        }
    }

    public class LTetrad : Tetrad
    {
        public LTetrad()
        {
            TetradType[,] block = new TetradType[Width, Height];
            block[0, 0] = block[1, 0] = block[2, 0] = block[0, 1] = TetradType.L;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[0, 0] = block[0, 1] = block[0, 2] = block[1, 2] = TetradType.L;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[2, 0] = block[0, 1] = block[1, 1] = block[2, 1] = TetradType.L;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[0, 0] = block[1, 0] = block[1, 1] = block[1, 2] = TetradType.L;
            mBlocks.Add(block);
        }
    }

    public class OTetrad : Tetrad
    {
        public OTetrad()
        {
            TetradType[,] block = new TetradType[Width, Height];
            block[0, 0] = block[1, 0] = block[0, 1] = block[1, 1] = TetradType.O;
            mBlocks.Add(block);
        }
    }

    public class STetrad : Tetrad
    {
        public STetrad()
        {
            TetradType[,] block = new TetradType[Width, Height];
            block[1, 0] = block[2, 0] = block[0, 1] = block[1, 1] = TetradType.S;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[0, 0] = block[0, 1] = block[1, 1] = block[1, 2] = TetradType.S;
            mBlocks.Add(block);
        }
    }

    public class TTetrad : Tetrad
    {
        public TTetrad()
        {
            TetradType[,] block = new TetradType[Width, Height];
            block[0, 0] = block[1, 0] = block[2, 0] = block[1, 1] = TetradType.T;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[0, 0] = block[0, 1] = block[0, 2] = block[1, 1] = TetradType.T;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[1, 0] = block[0, 1] = block[1, 1] = block[2, 1] = TetradType.T;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[0, 1] = block[1, 0] = block[1, 1] = block[1, 2] = TetradType.T;
            mBlocks.Add(block);

        }
    }

    public class ZTetrad : Tetrad
    {
        public ZTetrad()
        {
            TetradType[,] block = new TetradType[Width, Height];
            block[0, 0] = block[1, 0] = block[1, 1] = block[2, 1] = TetradType.Z;
            mBlocks.Add(block);

            block = new TetradType[Width, Height];
            block[1, 0] = block[0, 1] = block[1, 1] = block[0, 2] = TetradType.Z;
            mBlocks.Add(block);
        }
    }
}
