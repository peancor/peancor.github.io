﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Diagnostics;
using System.ComponentModel;

namespace SilTetris
{
    public enum GameState
    {
        Start,
        Running,
        GameOver,
    }

    public class Model: INotifyPropertyChanged
    {
        #region Fields
        //Field size (in blocks)
        public const int Width = 10;
        public const int Height = 20;
        //
        GameState _GameState;
        DispatcherTimer mTimer;
        //        
        Int32 _Level;
        Int32 mUpdateDecimate;
        Int32 mNextLevel;
        Int32 mLevelLineCount;
        Int32 mTotalLineCount;
        //
        Int32 _Score;
        //
        Tetrad mCurrentTetrad;
        Tetrad _NextTetrad;
        Int32 mTetradLine, mTetradColumn;
        //        
        readonly TetradType[,] mPlayFieldMatrix = new TetradType[Width, Height];

        #endregion

        #region Events

        public event Action Updated;
        public event Action LevelUp;
        public event Action LineCompleted;

        #endregion

        #region Game Properties

        public TetradType this[Int32 x, Int32 y]
        {
            get { return mPlayFieldMatrix[x, y]; }
        }

        public Tetrad NextTetrad
        {
            get { return _NextTetrad; }
            set { _NextTetrad = value; RaisePropertyChanged("NextTetrad"); }
        }

        public Int32 Score
        {
            get { return _Score; }
            set { _Score = value; RaisePropertyChanged("Score"); }
        }


        public Int32 Level
        {
            get { return _Level; }
            set { _Level = value; RaisePropertyChanged("Level"); }
        }
 
        public GameState GameState
        {
            get { return _GameState; }
            private set { _GameState = value; RaisePropertyChanged("GameState"); }
        }

        #endregion

        #region String Resource Properties

        public String LevelString
        {
            get { return StringResources.Level; }
        }

        public String ScoreString
        {
            get { return StringResources.Score; }
        }

        public String ClickToPlayString
        {
            get { return StringResources.ClickToPlay; }
        }

        public String ClickToReplayString
        {
            get { return StringResources.ClickToReplay; }
        }

        public String NextString
        {
            get { return StringResources.Next; }
        }

        public String TotalScoreString
        {
            get { return StringResources.TotalScore; }
        }

        #endregion

        #region Initialization

        public Model()
        {
            GameState = GameState.Start;
        }

        public void Initialize()
        {
            mTimer = new DispatcherTimer();
            mTimer.Interval = TimeSpan.FromMilliseconds(20);
            mTimer.Tick += new EventHandler(mTimer_Tick);
        }

        #endregion

        #region Game Restart

        public void StartGame()
        {
            ClearPlayField();
            Score = 0;
            Level = 1;

            mNextLevel = 3;
            mLevelLineCount = 0;
            mTotalLineCount = 0;
            mUpdateDecimate = 0;

            NextTetrad = TetradFactory.CreateRandom();
            AddTetrad();

            mTimer.Start();
            GameState = GameState.Running;
        }

        #endregion

        #region Helper Methods

        void ClearPlayField()
        {
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    mPlayFieldMatrix[x, y] = TetradType.None;
                }
            }
        }

        /// <summary>
        /// Adds a new tetrad to the game. If a new tetrad can not be added, the game is over.
        /// </summary>
        void AddTetrad()
        {
            Debug.Assert(NextTetrad != null);

            mCurrentTetrad = NextTetrad;
            mTetradLine = 0;
            mTetradColumn = 4;
            NextTetrad = TetradFactory.CreateRandom();
            if (CanMoveTetrad(mCurrentTetrad, 0, 4) == true)
            {
                MoveTetrad(mCurrentTetrad, 0, 4);
            }
            else
            {
                GameState = GameState.GameOver;
                mTimer.Stop();
            }
        }

        /// <summary>
        /// Deletes a tetrad from the play field
        /// </summary>
        /// <param name="tetrad"></param>
        /// <param name="line"></param>
        /// <param name="column"></param>
        void DeleteTetrad(Tetrad tetrad, Int32 line, Int32 column)
        {
            for (int y = 0; y < Tetrad.Height; y++)
            {
                for (int x = 0; x < Tetrad.Width; x++)
                {
                    Int32 modelX = x + column;
                    Int32 modelY = y + line;
                    if (modelX < 0 || modelX >= Model.Width || modelY < 0 || modelY >= Model.Height)
                    {
                    }
                    else if (tetrad[x, y] != TetradType.None)
                    {
                        mPlayFieldMatrix[modelX, modelY] = TetradType.None;
                    }
                }
            }
        }

        /// <summary>
        /// Check if a tetrad can be moved to a position of the playfield
        /// </summary>
        /// <param name="tetrad"></param>
        /// <param name="line"></param>
        /// <param name="column"></param>
        /// <returns></returns>
        Boolean CanMoveTetrad(Tetrad tetrad, Int32 line, Int32 column)
        {
            for (int y = 0; y < Tetrad.Height; y++)
            {
                for (int x = 0; x < Tetrad.Width; x++)
                {
                    Int32 modelX = x + column;
                    Int32 modelY = y + line;
                    //Check collision with the border of the play field
                    if (modelX < 0 || modelX >= Model.Width || modelY < 0 || modelY >= Model.Height)
                    {
                        if (tetrad[x, y] != TetradType.None)
                            return false;
                    }
                    //Check collisions with another blocks
                    else if ( 
                        (mPlayFieldMatrix[modelX, modelY]!= TetradType.None) && (tetrad[x, y]!= TetradType.None)
                        )
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Sets a tetrad into the playfield
        /// </summary>
        /// <param name="tetrad"></param>
        /// <param name="line"></param>
        /// <param name="column"></param>
        void MoveTetrad(Tetrad tetrad, Int32 line, Int32 column)
        {
            for (int y = 0; y < Tetrad.Height; y++)
            {
                for (int x = 0; x < Tetrad.Width; x++)
                {
                    Int32 modelX = x + column;
                    Int32 modelY = y + line;
                    if (modelX < 0 || modelX >= Model.Width || modelY < 0 || modelY >= Model.Height)
                    {
                    }
                    else
                    {
                        if (tetrad[x,y]!= TetradType.None)
                            mPlayFieldMatrix[modelX, modelY] = tetrad[x, y];
                    }
                }
            }
        }

        /// <summary>
        /// Check if the current tetra can be move to the parameter position and moves it;
        /// </summary>
        /// <param name="line"></param>
        /// <param name="column"></param>
        /// <returns></returns>
        bool CheckAndMove(int line, int column)
        {
            DeleteTetrad(mCurrentTetrad, mTetradLine, mTetradColumn);
            if (CanMoveTetrad(mCurrentTetrad, line, column) == true)
            {
                MoveTetrad(mCurrentTetrad, line, column);
                mTetradLine = line;
                mTetradColumn = column;
                RaiseUpdated();
                return true;
            }
            else
            {
                MoveTetrad(mCurrentTetrad, mTetradLine, mTetradColumn);
                return false;
            }
        }

        /// <summary>
        /// Finds and removes completed lines in the play field, updates the score, and upgrade the level if necesary
        /// </summary>
        void CheckForCompletedLines()
        {
            int linesRemoved = 0;

            for (int y = 0; y < Height; y++)
            {
                bool line = true;
                for (int x = 0; x < Width; x++)
                {
                    line &= (mPlayFieldMatrix[x, y] != TetradType.None);
                }
                if (line == true)
                {
                    RemoveLine(y);
                    linesRemoved++;
                    mTotalLineCount++;
                }
            }

            Score += (Int32)(50 * Level * Math.Pow(linesRemoved, 2));
            mLevelLineCount+=linesRemoved;
            //Check for level upgrade
            if (mLevelLineCount >= mNextLevel)
            {
                mNextLevel *= 2;
                mLevelLineCount = 0;
                Level++;
                RaiseLevelUp();
            }
        }

        /// <summary>
        /// Remove the parameter line from the playfield, displacing all the lines above it.
        /// </summary>
        /// <param name="index"></param>
        void RemoveLine(int index)
        {
            for (int y = index; y > 0; y--)
            {
                for (int x = 0; x < Width; x++)
                {
                    mPlayFieldMatrix[x, y] = mPlayFieldMatrix[x, y - 1];
                }
            }
            for (int x = 0; x < Width; x++)
            {
                mPlayFieldMatrix[x, 0] = TetradType.None;
            }
            RaiseLineCompleted();
        }

        #endregion

        #region Game Loop And Updating Logic

        void mTimer_Tick(object sender, EventArgs e)
        {
            mUpdateDecimate++;

            int updateLevel = 11 - Level;
            if (updateLevel < 0) updateLevel = 0;
            if (mUpdateDecimate > updateLevel)
            {
                mUpdateDecimate = 0;
                Update();
            }
        }

        void Update()
        {
            if (mCurrentTetrad != null)
            {
                if (CheckAndMove(mTetradLine + 1, mTetradColumn) == false)
                {
                    CheckForCompletedLines();
                    AddTetrad();
                }
            }
        }

        public void KeyDown(Key key)
        {
            if (mCurrentTetrad != null)
            {
                switch (key)
                {
                    case Key.Left:
                        CheckAndMove(mTetradLine, mTetradColumn - 1);
                        break;
                    case Key.Right:
                        CheckAndMove(mTetradLine, mTetradColumn + 1);
                        break;
                    case Key.Down:
                        if (CheckAndMove(mTetradLine +1, mTetradColumn))
                            Score += Level;
                        break;
                    case Key.Space:
                        DeleteTetrad(mCurrentTetrad, mTetradLine, mTetradColumn);
                        mCurrentTetrad.RotateForward();
                        if (CanMoveTetrad(mCurrentTetrad, mTetradLine, mTetradColumn))
                        {
                            MoveTetrad(mCurrentTetrad, mTetradLine, mTetradColumn);
                        }
                        else
                        {
                            mCurrentTetrad.RotateBackward();
                            MoveTetrad(mCurrentTetrad, mTetradLine, mTetradColumn);
                        }
                        RaiseUpdated();
                        break;
                }
            }
        }

        #endregion

        #region Event Raising Helper Methods

        void RaiseUpdated()
        {
            if (Updated != null) Updated();
        }

        void RaiseLineCompleted()
        {
            if (LineCompleted != null) LineCompleted();
        }

        void RaiseLevelUp()
        {
            if (LevelUp != null) LevelUp();
        }

        #endregion

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
