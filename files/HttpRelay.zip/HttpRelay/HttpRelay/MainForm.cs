﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml;
using System.Net;

namespace HttpRelay
{
    public partial class MainForm : Form
    {
        readonly List<HttpRelay> mRelays = new List<HttpRelay>();

        public MainForm()
        {
            InitializeComponent();            
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
            this.ShowInTaskbar = false;
            base.OnClosing(e);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //Mostramos el icono de notificación
            mNotifyIcon.Visible = true;

            try
            {
                //Cargamos el fichero de configuración e instanciamos los relays que 
                //en el se definen
                XDocument doc = XDocument.Load("PortsToForward.xml");
                var relayData = (from f in doc.Descendants("Forward")
                                 select new
                                 {
                                     Uri = f.Attribute("Uri").Value,
                                     ComPort = f.Attribute("ComPort").Value,
                                     BaudRate = XmlConvert.ToInt32(f.Attribute("BaudRate").Value)
                                 }).ToArray();
                foreach (var r in relayData)
                {
                    HttpRelay relay = new HttpRelay(r.ComPort, r.BaudRate, r.Uri);
                    mRelays.Add(relay);
                }
            }
            catch (HttpListenerException ex)
            {
                MessageBox.Show(string.Format("No se ha podido establecer la redireccíón: {0}", ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
        }

        private void mExitMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void laciudadelaLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.laciudadela.net");
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
            this.ShowInTaskbar = true;
            this.Focus();
        }

        private void mNotifyIcon_DoubleClick(object sender, EventArgs e)
        {
            this.Show();
            this.ShowInTaskbar = true;
            this.Focus();
        } 
    }
}
