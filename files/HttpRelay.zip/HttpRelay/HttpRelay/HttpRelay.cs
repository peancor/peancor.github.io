﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net;
using System.IO.Ports;
using System.IO;

namespace HttpRelay
{
    public class HttpRelay
    {
        string mComPort;
        int mBaudRate;
        string mHttpUri;
        int mTimeOut = 3000;
        readonly Thread mWorkerThread;
        readonly HttpListener mListener;

        public HttpRelay(string comPort, int baudRate, string httpUri)
        {
            mComPort = comPort;
            mBaudRate = baudRate;
            mHttpUri = httpUri;
            //
            mListener = new HttpListener();
            mListener.Prefixes.Add(mHttpUri);
            mListener.Start();
            //
            mWorkerThread = new Thread(WorkerThreadHandler);
            mWorkerThread.Priority = ThreadPriority.BelowNormal;
            mWorkerThread.IsBackground = true;
            mWorkerThread.Start();
        }

        void WorkerThreadHandler()
        {
            SerialPort port = new SerialPort(mComPort, mBaudRate);
            port.NewLine = "\r\n";
            port.ReadTimeout = mTimeOut;
            port.WriteTimeout = mTimeOut;

            while (true)
            {
                var context = mListener.GetContext();
                var query = context.Request.QueryString["q"];

                try
                {
                    if (query == null)
                    {
                        WriteResponse(context, "a query parameter is required");
                        continue;
                    }
                    //
                    port.Open();
                    port.DiscardInBuffer();
                    port.Write(query);
                    var responseLine = port.ReadLine();
                    WriteResponse(context, responseLine);
                    //
                }
                catch (TimeoutException)
                {
                    context.Response.StatusCode = 500;
                    //Una excepción de timeout, escribimos timeout
                    WriteResponse(context, "Error: timeout");
                }
                catch (Exception ex)
                {
                    context.Response.StatusCode = 500;
                    WriteResponse(context, string.Format("Error: {0}", ex.Message));
                }
                finally
                {
                    if (port.IsOpen)
                        port.Close();
                }
            }            
        }

        void WriteResponse(HttpListenerContext context, string response)
        {
            try
            {
                using (var outputStream = context.Response.OutputStream)
                {
                    byte[] buffer = Encoding.UTF8.GetBytes(response);
                    context.Response.ContentType = "text/plain";
                    context.Response.ContentLength64 = buffer.Length;
                    outputStream.Write(buffer, 0, buffer.Length);
                }
            }
            catch (Exception ex)
            {
                //Si no se puede enviar la respuesta no pasa nada
                System.Diagnostics.Debug.WriteLine("No se pudo enviar la respuesta: " + ex.Message);
            }
        }
    }
}
