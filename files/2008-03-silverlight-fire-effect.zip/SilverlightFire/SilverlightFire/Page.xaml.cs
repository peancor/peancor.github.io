﻿/*
 * 
 * Basado en el efecto fuego de 'The Demo Effect Collection':
 *  http://demo-effects.sourceforge.net/
 *  Para mas información consultar el archivo fire.c de dicha colección,
 *  el cual está escrito por W.P. van Paassen - peter@paassen.tmfweb.nl
 *---------------------------------------------------------------------- 
 *Escrito por peancor@hotmail.com
 */

#region Usings

using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

#endregion

namespace SilverlightFire
{
    public partial class Page : UserControl
    {
        #region Fields

        int _horizontalCellCount = 36;
        int _verticalCellCount = 24;
        Rectangle[] _cells;
        Color[] _colors;
        Brush[] _brushes;
        DispatcherTimer _timer;
        int[] _fire;

        #endregion

        #region Initialization / Disposal

        public Page()
        {
            InitializeComponent();

            //Inicializamos el timer
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(250);
            _timer.Tick += delegate { UpdateEffect(); };
            //Cuando se cargue la página activamos el timer
            this.Loaded += delegate { _timer.Start(); };
            //
            SizeChanged += new SizeChangedEventHandler(Page_SizeChanged);
        }

        void Page_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (ActualWidth > 0 && ActualHeight > 0)
            {
                //Reiniciamos el efecto
                InitializeEffect();
            }
        }

        #endregion

        #region Effect Initialization

        void InitializeEffect()
        {
            _colors = new Color[256];
            for (int i = 0; i < 32; ++i)
            {
                /* black to blue, 32 values*/
                _colors[i].A = 255;
                _colors[i].B = (byte)(i << 1);

                /* blue to red, 32 values*/
                _colors[i + 32].A = 255;
                _colors[i + 32].R = (byte)(i << 3);
                _colors[i + 32].B = (byte)(64 - (i << 1));

                /*red to yellow, 32 values*/
                _colors[i + 64].A = 255;
                _colors[i + 64].R = 255;
                _colors[i + 64].G = (byte)(i << 3);

                /* yellow to white, 162 */
                _colors[i + 96].A = 255;
                _colors[i + 96].R = 255;
                _colors[i + 96].G = 255;
                _colors[i + 96].B = (byte)(i << 2);

                _colors[i + 128].A = 255;
                _colors[i + 128].R = 255;
                _colors[i + 128].G = 255;
                _colors[i + 128].B = (byte)(64 + (i << 2));

                _colors[i + 160].A = 255;
                _colors[i + 160].R = 255;
                _colors[i + 160].G = 255;
                _colors[i + 160].B = (byte)(128 + (i << 2));

                _colors[i + 192].A = 255;
                _colors[i + 192].R = 255;
                _colors[i + 192].G = 255;
                _colors[i + 192].B = (byte)(192 + i);

                _colors[i + 224].A = 255;
                _colors[i + 224].R = 255;
                _colors[i + 224].G = 255;
                _colors[i + 224].B = (byte)(224 + i);
            }

            _brushes = (from color in _colors
                        select new SolidColorBrush(color)).ToArray();

            _cells = new Rectangle[_horizontalCellCount * _verticalCellCount];
            _fire = new int[_horizontalCellCount * _verticalCellCount];

            //Creamos y posicionamos la geometria
            for (int y = 0; y < _verticalCellCount; y++)
            {
                for (int x = 0; x < _horizontalCellCount; x++)
                {
                    //creamos la primitive
                    Rectangle shape = new Rectangle();
                    shape.Width = (ActualWidth / _horizontalCellCount) - 2; //
                    shape.Height = (ActualHeight / _verticalCellCount) - 2; //restamos 2 debido al margen
                    shape.Margin = new Thickness(1);
                    //y la posicionamos
                    Canvas.SetLeft(shape, x * ActualWidth / _horizontalCellCount);
                    Canvas.SetTop(shape, y * ActualHeight / _verticalCellCount);
                    //y añadimos al canvas y a la coleccion de celdas
                    canvas.Children.Add(shape);
                    _cells[y * _horizontalCellCount + x] = shape;
                }
            }
        }

        #endregion

        #region Effect Updating

        void UpdateEffect()
        {
            /* draw random bottom line in fire array*/
            Random random = new Random();
            int y = _verticalCellCount - 1;
            for (int x = 0; x < _horizontalCellCount; x++)
            {
                int randomValue = random.Next(1, 16);
                if (randomValue > 9) /* the lower the value, the intenser the fire, compensate a lower value with a higher decay value*/
                    _fire[_horizontalCellCount * y + x] = 255; /*maximum heat*/
                else
                    _fire[_horizontalCellCount * y + x] = 0;
            }

            /* move fire upwards, start at bottom*/

            int j = _horizontalCellCount * (_verticalCellCount - 1);
            for (int index = 0; index < _verticalCellCount-1; ++index)
            {
                int temp = 0;

                for (int i = 0; i < _horizontalCellCount; ++i)
                {
                    if (i == 0) /* at the left border*/
                    {
                        temp = _fire[j];
                        temp += _fire[j + 1];
                        temp += _fire[j - _horizontalCellCount];
                        temp /= 3;
                    }
                    else if (i == _horizontalCellCount - 1) /* at the right border*/
                    {
                        temp = _fire[j + i];
                        temp += _fire[j - _horizontalCellCount + i];
                        temp += _fire[j + i - 1];
                        temp /= 3;
                    }
                    else
                    {
                        temp = _fire[j + i];
                        temp += _fire[j + i + 1];
                        temp += _fire[j + i - 1];
                        temp += _fire[j - _horizontalCellCount + i];
                        temp >>= 2;
                    }
                    if (temp > 1)
                        temp -= 1; /* decay */

                    _fire[j - _horizontalCellCount + i] = temp;
                }
                j -= _horizontalCellCount;
            }

            for (int i = 0; i < _cells.Length; i++)
                _cells[i].Fill = _brushes[_fire[i]];
        }

        #endregion
    }
}
