﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.IO.Ports;
using System.Threading;

namespace ServoControl
{
    class ServoController : INotifyPropertyChanged, IDisposable
    {
        SerialPort mPort;
        int mServoPos;

        public int ServoPos
        {
            get { return mServoPos; }
            set { SetServo(value); SignalPropertyChanged("ServoPos"); }
        }

        public ServoController()
        {
            mPort = new SerialPort("Com3") { BaudRate = 115200, NewLine = "\r" };
            mPort.Open();
            SetServo(0);
        }

        private void SetServo(int value)
        {
            if (value < 0) value = 0;
            if (value > 175) value = 175;
            mPort.WriteLine("SERVO " + value.ToString());
            mServoPos = value;
            Thread.Sleep(15);
        }


        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        void SignalPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            mPort.Close();
        }

        #endregion
    }
}
