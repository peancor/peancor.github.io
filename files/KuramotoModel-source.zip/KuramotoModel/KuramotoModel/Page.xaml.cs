﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace KuramotoModel
{
    public partial class Page : UserControl
    {
        readonly List<Oscillator> mOscillators = new List<Oscillator>();
        DateTime mLastUpdate = DateTime.Now;
        readonly Random mRandom = new Random();

        public Page()
        {
            InitializeComponent();            

            mKSlider.ValueChanged += delegate { RefreshUI(); };
            CompositionTarget.Rendering += new EventHandler(CompositionTarget_Rendering);

        }

        void ResetSimulation()
        {
            mKSlider.Value = 5;
            mOscillators.Clear();
            mSimulationCanvas.Children.Clear();
            AddRandom(25, 5, Math.PI);
            RefreshUI();
        }

        void RefreshUI()
        {
            mKTextBlock.Text = string.Format("K ({0}): ", mKSlider.Value.ToString("F3"));
        }

        void AddRandom(int n, double wMod, double pMod)
        {
            for (int i = 0; i < n; i++)
            {
                AddOscillator(GetRandom(-wMod,wMod), GetRandom(-pMod, pMod),
                    Color.FromArgb((byte)mRandom.Next(64, 255), (byte)mRandom.Next(0, 256), (byte)mRandom.Next(0, 256), (byte)mRandom.Next(0, 256)));
            }
        }

        void AddOscillator(double w, double phi, Color c)
        {
            Oscillator o = new Oscillator(w, phi, c);
            mSimulationCanvas.Children.Add(o.Circle);
            mOscillators.Add(o);
        }

        void CompositionTarget_Rendering(object sender, EventArgs e)
        {
            var now = DateTime.Now;
            double elapsed = (now - mLastUpdate).TotalSeconds;
            mLastUpdate = now;
            //elapsed = 0.05;

            int N = mOscillators.Count;
            double[] OldPhis = (from o in mOscillators
                                select o.Phi).ToArray();
            double[] dPhi = new Double[N];
            for (int i = 0; i < N; i++)
            {
                dPhi[i] += mOscillators[i].W;
                for (int k = 0; k < N; k++)
                {
                    dPhi[i] += (mKSlider.Value / N) * Math.Sin(OldPhis[k] - OldPhis[i]);
                }
            }
            for (int i = 0; i < N; i++)
            {
                mOscillators[i].Phi = OldPhis[i] + (dPhi[i] ) * elapsed;
                mOscillators[i].Radius = 50 + Clamp(10 * dPhi[i], -50, 50);

                mOscillators[i].Update();
            }
        }

        double Clamp(double value, double min, double max)
        {
            if (value < min)
                return min;
            else if (value > max)
                return max;
            else
                return value;
        }

        Double GetRandom(double min, double max)
        {
            var r = mRandom.Next(0, 10000);
            return min + (r / 9999.0) * (max - min);
        }

        private void mResetButton_Click(object sender, RoutedEventArgs e)
        {
            mControlPanelBorder.Visibility = Visibility.Visible;
            mResetButton.Content = "Reiniciar simulación";
            mResetButton.FontSize = 12;
            mResetButton.VerticalAlignment = VerticalAlignment.Bottom;
            mResetButton.HorizontalAlignment = HorizontalAlignment.Right;
            mResetButton.Opacity = 0.7;
            ResetSimulation();
        }
    }
}