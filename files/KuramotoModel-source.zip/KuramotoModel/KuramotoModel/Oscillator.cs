﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace KuramotoModel
{
    public class Oscillator
    {
        public Ellipse Circle { get; set; }
        public Double W { get; set; }
        public Double Phi { get; set; }
        public Double Radius { get; set; }
        public Point Center { get; set; }        

        public Oscillator(Double w, double phi, Color c)
        {
            W = w;
            Phi = phi;
            Radius = 100;
            Center = new Point(200, 150);
            Circle = new Ellipse() { Width = 32, Height = 32, Fill = new SolidColorBrush(c) };
        }

        public void Update()
        {            
            double x = Radius * Math.Cos(Phi);
            double y = Radius * Math.Sin(Phi);
            Canvas.SetLeft(Circle, Center.X - x);
            Canvas.SetTop(Circle, Center.Y - y);
        }
    }
}
