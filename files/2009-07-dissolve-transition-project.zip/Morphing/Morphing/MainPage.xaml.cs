﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Morphing
{
    public partial class MainPage : UserControl
    {
        WriteableBitmap mSourceBitmap;
        WriteableBitmap mTargetBitmap;
        WriteableBitmap mCompositionBitmap;        
        double mStep = 0.04;
        DispatcherTimer mTimer;

        public MainPage()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            BitmapImage bmi = new BitmapImage(new Uri("flower-source.jpg", UriKind.Relative)) { CreateOptions = BitmapCreateOptions.None };
            mSourceImage.Source = bmi;
            bmi.ImageOpened += (o, ee) =>
            {
                mSourceBitmap = new WriteableBitmap(bmi);
                mSourceImage.Source = mSourceBitmap;
                mCompositionBitmap = new WriteableBitmap(bmi);
                mCompositionImage.Source = mCompositionBitmap;
            };
            BitmapImage targetBmi = new BitmapImage(new Uri("flower-target.jpg", UriKind.Relative)) { CreateOptions = BitmapCreateOptions.None };
            mTargetImage.Source = targetBmi;
            targetBmi.ImageOpened += (o, ee) =>
            {
                mTargetBitmap = new WriteableBitmap(targetBmi);
                mTargetImage.Source = mTargetBitmap;
            };
            mTimer = new DispatcherTimer();
            mTimer.Interval = TimeSpan.FromMilliseconds(50);
            mTimer.Tick += new EventHandler(mTimer_Tick);
        }

        void mTimer_Tick(object sender, EventArgs e)
        {
            mSlider.Value += mStep;            
            if (mSlider.Value >= 1) mTimer.Stop();
        }

        private void mPlayButton_Click(object sender, RoutedEventArgs e)
        {
            mSlider.Value = 0;
            mTimer.Start();
        }

        void SetT(Double t)
        {
            if (t < 0) t = 0;
            if (t > 1) t = 1;

            int width = mSourceBitmap.PixelWidth;
            int height = mSourceBitmap.PixelHeight;

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    int index = y * width + x;
                    var sourceBytes = BitConverter.GetBytes(mSourceBitmap.Pixels[index]);
                    var targetBytes = BitConverter.GetBytes(mTargetBitmap.Pixels[index]);
                    byte[] compositionBytes = new byte[4];
                    for (int i = 0; i < 4; i++)
                    {                        
                        compositionBytes[i] = (byte)((1 - t) * sourceBytes[i] + t * targetBytes[i]);                        
                    }                    
                    mCompositionBitmap.Pixels[index] = BitConverter.ToInt32(compositionBytes, 0);
                }
            }
            mCompositionBitmap.Invalidate();
        }

        private void mSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SetT(mSlider.Value);
        }
    }
}