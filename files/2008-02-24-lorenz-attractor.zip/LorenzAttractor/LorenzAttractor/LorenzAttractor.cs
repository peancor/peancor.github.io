#region File Description
//-----------------------------------------------------------------------------
// Projectile.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

#region Using Statements
using System;
using Microsoft.Xna.Framework;
#endregion

//namespace Particle3DSample
namespace LorenzAttractor
{
    /// <summary>
    /// This class demonstrates how to combine several different particle systems
    /// to build up a more sophisticated composite effect. It implements a rocket
    /// projectile, which arcs up into the sky using a ParticleEmitter to leave a
    /// steady stream of trail particles behind it. After a while it explodes,
    /// creating a sudden burst of explosion and smoke particles.
    /// </summary>
    class LorenzAttractor
    {
        #region Constants

        const float trailParticlesPerSecond = 200;
        const int numExplosionParticles = 30;
        const int numExplosionSmokeParticles = 50;
        const float projectileLifespan = 1.5f;
        const float sidewaysVelocityRange = 60;
        const float verticalVelocityRange = 40;
        const float gravity = 15;

        #endregion

        #region Fields

        float a = 10;
        float b = 8f / 3f;
        float c = 28;

        ParticleEmitter trailEmitter;
        ParticleEmitter leadEmitter;

        Vector3 position;
        float age;

        static Random random = new Random();

        #endregion


        /// <summary>
        /// Constructs a new projectile.
        /// </summary>
        public LorenzAttractor(ParticleSystem leadParticles,                          
                          ParticleSystem trailParticles)
        {
            // Start at the origin, firing in a random (but roughly upward) direction.
            position = new Vector3(.001f, .001f, .001f);

            //UpdateVelocity(0);

            // Use the particle emitter helper to output our trail particles.
            trailEmitter = new ParticleEmitter(trailParticles,
                                               trailParticlesPerSecond, position);

            leadEmitter = new ParticleEmitter(leadParticles,
                                              100, position);
        }

        Vector3 ComputeVelocity()
        {
            float x = (a * (position.Y - position.X));
            float y = (position.X * (c - position.Z) - position.Y);
            float z = (position.X * position.Y - b * position.Z);
            return new Vector3(x, y, z);
        }

        /// <summary>
        /// Updates the projectile.
        /// </summary>
        public bool Update(GameTime gameTime)
        {
            float elapsedTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            //Position update
            position += ComputeVelocity() * elapsedTime;
            
            age += elapsedTime;

            // Update the particle emitter, which will create our particle trail.
            trailEmitter.Update(gameTime, new Vector3(position.X, position.Z, position.Y));
            leadEmitter.Update(gameTime, new Vector3(position.X, position.Z, position.Y));

            return true;
        }
    }
}
