﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Kit3D.Windows.Media.Media3D;
using Kit3D.Windows.Media;
using Kit3D.Windows.Controls;

namespace Kit3DHeartbeat
{
    public partial class Page : UserControl
    {
        private Random mRandom = new Random();
        const Double MinRadius = 1.5;
        const Double MaxRadius = 2.5;
        bool mIsRunning;
        DateTime mStartedTime;
        TimeSpan mMaxRunningTime = TimeSpan.FromSeconds(30);
        //
        private Viewport3D mViewport;
        private ModelVisual3D mModelVisual;
        private RotateTransform3D mGroupRotationX, mGroupRotationY;
        private Model3DGroup mCubeGroup;

        public Page()
        {
            InitializeComponent();
            mHeartbeatMediaElement.MediaEnded += (o, e) =>
            {
                if (mIsRunning == true)
                {
                    mHeartbeatMediaElement.Position = TimeSpan.Zero;
                    mHeartbeatMediaElement.Play();
                }
            };

            mViewport = new Viewport3D();
            mViewport.HorizontalAlignment = HorizontalAlignment.Stretch;
            mViewport.VerticalAlignment = VerticalAlignment.Stretch;
            mViewport.Camera = new PerspectiveCamera(new Point3D(0, 10, 0),
                                                    new Vector3D(0, -10, 0),
                                                    new Vector3D(1, 0, 0),
                                                    45);

            mModelVisual = LoadScene();
            mViewport.Children.Add(mModelVisual);

            mViewport.ShowModelBoundingBoxes = true;

            this.mCanvas3D.Children.Add(mViewport);

            Kit3D.Windows.Media.CompositionTarget.Rendering += new EventHandler(CompositionTarget_Rendering);
        }

        void Run()
        {
            mStartedTime = DateTime.Now;
            mIsRunning = true;
            mHeartbeatMediaElement.Position = TimeSpan.Zero;
            mHeartbeatMediaElement.Play();
            mStartButton.Visibility = Visibility.Collapsed;
            mStopButton.Visibility = Visibility.Visible;
        }

        void Stop()
        {
            LayoutRoot.Opacity = 1;
            mIsRunning = false;
            mStartButton.Visibility = Visibility.Visible;
            mStopButton.Visibility = Visibility.Collapsed;
        }

        private MeshGeometry3D CreateCubeMesh()
        {
            MeshGeometry3D mesh = new MeshGeometry3D();
            mesh.Positions = new Point3DCollection
            {
                new Point3D(0,0,0),
                new Point3D(1,0,0),
                new Point3D(1,0,1),
                new Point3D(0,0,0),
                new Point3D(1,0,1),
                new Point3D(0,0,1),
                new Point3D(0,1,0),
                new Point3D(1,1,1),
                new Point3D(1,1,0),
                new Point3D(0,1,0),
                new Point3D(0,1,1),
                new Point3D(1,1,1),
                new Point3D(0,0,0),
                new Point3D(0,1,0),
                new Point3D(1,1,0),
                new Point3D(0,0,0),
                new Point3D(1,1,0),
                new Point3D(1,0,0),
                new Point3D(1,0,0),
                new Point3D(1,1,0),
                new Point3D(1,1,1),
                new Point3D(1,0,0),
                new Point3D(1,1,1),
                new Point3D(1,0,1),
                new Point3D(1,0,1),
                new Point3D(1,1,1),
                new Point3D(0,1,1),
                new Point3D(1,0,1),
                new Point3D(0,1,1),
                new Point3D(0,0,1),
                new Point3D(0,0,1),
                new Point3D(0,1,1),
                new Point3D(0,1,0),
                new Point3D(0,0,1),
                new Point3D(0,1,0),
                new Point3D(0,0,0)
            };

            mesh.TriangleIndices = new Int32Collection
            {
                0,1,2,3,4,5,
                6,7,8,9,10,11,
                12,13,14,15,16,17,
                18,19,20,21,22,23,
                24,25,26,27,28,29,
                30,31,32,33,34,35
            };

            return mesh;
        }



        void UpdateTransforms(double progress)
        {
            int index = 0;
            double radius = MinRadius + (MaxRadius - MinRadius) * progress;

            for (Double yPhi = -Math.PI / 2; yPhi <= Math.PI / 2; yPhi += Math.PI / 8)
            {
                if (Math.Abs(yPhi) == Math.PI / 2) continue;
                Double yFactor = Math.Cos(yPhi);
                double y = radius * Math.Sin(yPhi);                

                for (Double phi = 0; phi < Math.PI * 2; phi += Math.PI / 6)
                {
                    var cube = mCubeGroup.Children[index];
                    double x = radius * Math.Cos(phi);
                    double z = radius * Math.Sin(phi);
                    cube.Transform = GetCubeTransforms(new Vector3D(x * yFactor, y, z * yFactor));
                    index++;
                }
            }
        }

        private ModelVisual3D LoadScene()
        {
            mCubeGroup = new Model3DGroup();
            Model3D cube;

            for (Double yPhi = -Math.PI / 2; yPhi <= Math.PI / 2; yPhi += Math.PI / 8)
            {
                if (Math.Abs(yPhi) == Math.PI / 2) continue;

                Double yFactor = Math.Cos(yPhi);
                double y = MinRadius * Math.Sin(yPhi);

                for (Double phi = 0; phi < Math.PI * 2; phi += Math.PI / 6)
                {
                    cube = GetCubeModel();
                    double x = MinRadius * Math.Cos(phi);
                    double z = MinRadius * Math.Sin(phi);
                    cube.Transform = GetCubeTransforms(new Vector3D(x * yFactor, y, z * yFactor));
                    mCubeGroup.Children.Add(cube);
                }
            }

            AxisAngleRotation3D rotationY = new AxisAngleRotation3D(new Vector3D(0, 1, 0), 360);
            RotateTransform3D groupSpinY = new RotateTransform3D(rotationY);
            AxisAngleRotation3D rotationX = new AxisAngleRotation3D(new Vector3D(1, 0, 0), 360);
            RotateTransform3D groupSpinX = new RotateTransform3D(rotationX);


            //TODO: Check WPF see how the bounds property works
            Rect3D groupRect = mCubeGroup.Bounds;
            groupSpinX.CenterX = groupRect.X + groupRect.SizeX / 2;
            groupSpinX.CenterY = groupRect.Y + groupRect.SizeY / 2;
            groupSpinX.CenterZ = groupRect.Z + groupRect.SizeZ / 2;
            groupSpinY.CenterX = groupRect.X + groupRect.SizeX / 2;
            groupSpinY.CenterY = groupRect.Y + groupRect.SizeY / 2;
            groupSpinY.CenterZ = groupRect.Z + groupRect.SizeZ / 2;

            /*
            groupSpinX.CenterX = width / 2;
            groupSpinX.CenterY = 0;
            groupSpinX.CenterZ = width / 2;
            groupSpinY.CenterX = 0;
            groupSpinY.CenterY = height / 2;
            groupSpinY.CenterZ = height / 2;
            */

            //Test out a transform group
            Transform3DGroup allTransforms = new Transform3DGroup();
            allTransforms.Children.Add(groupSpinY);
            allTransforms.Children.Add(groupSpinX);

            ModelVisual3D visual = new ModelVisual3D();
            visual.Content = mCubeGroup;
            visual.Transform = allTransforms;

            mGroupRotationX = groupSpinX;
            mGroupRotationY = groupSpinY;
            return visual;
        }

        private Transform3DGroup GetCubeTransforms(Vector3D finalTranslateVector)
        {
            Transform3DGroup transforms = new Transform3DGroup();
            TranslateTransform3D shrink = new TranslateTransform3D(-.5, 0, -.5);
            ScaleTransform3D scale = new ScaleTransform3D(new Vector3D(.4, .4, .4));
            TranslateTransform3D move = new TranslateTransform3D(finalTranslateVector);

            transforms.Children.Add(shrink);
            transforms.Children.Add(scale);
            transforms.Children.Add(move);
            return transforms;
        }

        private Model3D GetCubeModel()
        {
            GeometryModel3D geometry = new GeometryModel3D();
            geometry.Geometry = CreateCubeMesh();
            geometry.SeamSmoothing = 0.8;

            Material colorMaterial = new DiffuseMaterial(new Kit3DBrush(new SolidColorBrush(GetRandomColor())));
            geometry.Material = colorMaterial;
            return geometry;
        }

        private Color GetRandomColor()
        {
            int next = mRandom.Next(0, 100);

            if (next > 90)
            {
                return Colors.Red;
            }
            if (next > 80)
            {
                return Colors.Blue;
            }
            if (next > 70)
            {
                return Colors.Green;
            }
            if (next > 60)
            {
                return Colors.Brown;
            }
            if (next > 50)
            {
                return Colors.Purple;
            }
            if (next > 40)
            {
                return Colors.Yellow;
            }
            if (next > 30)
            {
                return Colors.Gray;
            }
            if (next > 20)
            {
                return Colors.Orange;
            }
            if (next > 10)
            {
                return Colors.Magenta;
            }

            return Colors.Orange;

        }
         
        void CompositionTarget_Rendering(object sender, EventArgs e)
        {
            if (mIsRunning == true)
            {
                //Check stop condition
                if (DateTime.Now - mStartedTime > mMaxRunningTime) Stop();
                //Update scene
                ((AxisAngleRotation3D)mGroupRotationX.Rotation).Angle -= 5;
                ((AxisAngleRotation3D)mGroupRotationY.Rotation).Angle -= 5;
                var progress = mHeartbeatMediaElement.Position.TotalMilliseconds / mHeartbeatMediaElement.NaturalDuration.TimeSpan.TotalMilliseconds;
                if (progress < 0) progress = 0;
                if (progress > 1) progress = 1;
                if (double.IsNaN(progress)) progress = 0;
                LayoutRoot.Opacity = 0.5 + progress;
                UpdateTransforms(progress);
            }
        }

        private void mStartButton_Click(object sender, RoutedEventArgs e)
        {
            Run();
        }

        private void mStopButton_Click(object sender, RoutedEventArgs e)
        {
            Stop();
        }
    }
}
