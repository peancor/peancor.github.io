﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.IO.Ports;

namespace LedRgb
{
    public class LedRgbModel : INotifyPropertyChanged
    {
        readonly SerialPort mPort;

        byte mRed;
        byte mGreen;
        byte mBlue;

        public byte Red
        {
            get { return mRed; }
            set { mRed = value; SetColor(mRed, mGreen, mBlue); SignalPropertyChanged("Red"); }
        }

        public byte Green
        {
            get { return mGreen; }
            set { mGreen = value; SetColor(mRed, mGreen, mBlue); SignalPropertyChanged("Green"); }
        }

        public byte Blue
        {
            get { return mBlue; }
            set { mBlue = value; SetColor(mRed, mGreen, mBlue); SignalPropertyChanged("Blue"); }
        }

        public LedRgbModel()
        {
            mPort = new SerialPort("Com3", 115200) { NewLine = "\r" };
            mPort.Open();
        }

        public void SetColor(byte r, byte g, byte b)
        {
            var message = string.Format("COLOR {0} {1} {2}", r, g, b);
            mPort.WriteLine(message);
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        void SignalPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
