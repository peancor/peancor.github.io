﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Effects;
using System.Windows.Media;
using System.Windows;

namespace SepiaEffectDemo
{
    public class SepiaEffect: ShaderEffect
    {
        public SepiaEffect()
        {
            PixelShader = _shader;
            UpdateShaderValue(InputProperty);
        }

        public Brush Input
        {
            get { return (Brush)GetValue(InputProperty); }
            set { SetValue(InputProperty, value); }
        }

        public static readonly DependencyProperty InputProperty =
            ShaderEffect.RegisterPixelShaderSamplerProperty(
                    "Input",
                    typeof(SepiaEffect),
                    0);

        private static PixelShader _shader =
            new PixelShader() { UriSource = new Uri(@"pack://application:,,,/SepiaEffectDemo;component/sepia-effect.ps") };

    }
}
