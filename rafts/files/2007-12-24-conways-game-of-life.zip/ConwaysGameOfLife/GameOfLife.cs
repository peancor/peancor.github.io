#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace ConwaysGameOfLife
{
    /// <summary>
    /// Representa los diferentes estados en los que puede estar el automato celular
    /// </summary>
    public enum CellState
    {
        Dead,
        Alive,
    }
    /// <summary>
    /// Contiene toda la logica del juego de la vida
    /// </summary>
    public class GameOfLife : Microsoft.Xna.Framework.Game
    {
        static Random random = new Random();

        GraphicsDeviceManager graphics;
        ContentManager content;
        SpriteBatch spriteBatch;
        SpriteFont comicSansFont;

        const int MaximumParticles = 5000;
        const int HorizontalCellCount = 50;
        const int VerticalCellCount = 50;

        int generationNumber;
        int aliveCellCount;
        bool needRedraw;
        int[] bornNeighbours = { 3 }; //N�mero de vecinos que necesita una celula para nacer
        int[] stayAliveNeighbours = { 2, 3 }; //Numero de vecinos que necesita una celula para permanecer viva = { 2, 3 };
        CellState[,] state; //rejilla de estado del automata celular
        TimeSpan cellularAutomatonPeriod = TimeSpan.FromMilliseconds(100); //El periodo de actualizacion del automata celular
        int gridX, gridY, gridWidth, gridHeight; //Coordenadas y dimensiones de la rejilla en unidades de representaci�n
        ParticleSystem particleSystem;
        DateTime lastUpdate = DateTime.MinValue;


        public GameOfLife()
        {
            //Iniciamos la tarjeta gr�fica
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = 853;
            graphics.PreferredBackBufferHeight = 480;
            //construimos el gestor de contenidos
            content = new ContentManager(Services, "content");
            //construimos el componente del sistema de part�culas
            particleSystem = new ExplosionParticleSystem(this, MaximumParticles);
            Components.Add(particleSystem);
        }


        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();

            //
            gridWidth = this.graphics.GraphicsDevice.Viewport.Width;
            gridHeight = this.graphics.GraphicsDevice.Viewport.Height;
            //Construimos la rejilla de estado del automata celular
            state = new CellState[HorizontalCellCount, VerticalCellCount];
            //
            Random r = new Random();
            state[1, 0] = CellState.Alive;
            state[1, 1] = CellState.Alive;
            state[2, 1] = CellState.Alive;
            state[0, 6] = CellState.Alive;
            state[2, 5] = CellState.Alive;
            state[2, 6] = CellState.Alive;
            state[2, 7] = CellState.Alive;

            for (int i = 10; i < 50; i++)
            {
                for (int j = 10; j < 50; j++)
                {
                    int random = r.Next(0, 100);
                    if (random > 50)
                        state[i, j] = CellState.Alive;
                }
            }
        }


        /// <summary>
        /// Load your graphics content.  If loadAllContent is true, you should
        /// load content from both ResourceManagementMode pools.  Otherwise, just
        /// load ResourceManagementMode.Manual content.
        /// </summary>
        /// <param name="loadAllContent">Which type of content to load.</param>
        protected override void LoadGraphicsContent(bool loadAllContent)
        {
            if (loadAllContent)
            {
                // TODO: Load any ResourceManagementMode.Automatic content
                spriteBatch = new SpriteBatch(this.graphics.GraphicsDevice);
                comicSansFont = content.Load<SpriteFont>("ComicSpriteFont");
            }

            // TODO: Load any ResourceManagementMode.Manual contents
        }


        /// <summary>
        /// Unload your graphics content.  If unloadAllContent is true, you should
        /// unload content from both ResourceManagementMode pools.  Otherwise, just
        /// unload ResourceManagementMode.Manual content.  Manual content will get
        /// Disposed by the GraphicsDevice during a Reset.
        /// </summary>
        /// <param name="unloadAllContent">Which type of content to unload.</param>
        protected override void UnloadGraphicsContent(bool unloadAllContent)
        {
            if (unloadAllContent)
            {
                // TODO: Unload any ResourceManagementMode.Automatic content
                content.Unload();
            }

            // TODO: Unload any ResourceManagementMode.Manual content
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();
            
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || keyboardState.IsKeyDown(Keys.Escape))
                this.Exit();

            // TODO: Add your update logic here
            base.Update(gameTime);

            //Comprobamos si debemos actualizar el automata celular
            if ((DateTime.Now - lastUpdate) > cellularAutomatonPeriod)
            {
                lastUpdate = DateTime.Now;
                //Actualizamos el n�mero de generaci�n
                generationNumber++;
                //Construimos el estado sucesor del anterior
                CellState[,] nextState = (CellState[,])state.Clone();
                //actualizamos cada celda de estado 
                for (int i = 0; i < VerticalCellCount; i++)
                {
                    for (int j = 0; j < HorizontalCellCount; j++)
                    {
                        //Si la celula considerada est� viva testamos por la condicion de muerte o supervivencia
                        if (state[i, j] == CellState.Alive)
                        {
                            if (TestSurviveCondition(i, j) == true)
                                nextState[i, j] = CellState.Alive;
                            else
                                nextState[i, j] = CellState.Dead;
                        }
                        else
                        {
                            //Testamos por la condicion de nacimiento
                            if (TestBornCondition(i, j) == true)
                                nextState[i, j] = CellState.Alive;
                            else
                                nextState[i, j] = CellState.Dead;
                        }
                    }
                }
                //Sustituimos la matriz de estado por la matriz de estado sucesor
                state = nextState;
                //Actualizamos el n�mero de celulas vivas
                aliveCellCount = CountAliveCells(state);
            }
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here
            base.Draw(gameTime);

            //
            //Para cada celda
            for (int i = 0; i < VerticalCellCount; i++)
            {
                for (int j = 0; j < HorizontalCellCount; j++)
                {
                    //Comprobamos si esta viva y en ese caso a�adimos particulas
                    if (state[i, j] == CellState.Alive)
                    {
                        float x = gridX + (1f * j / HorizontalCellCount) * (gridWidth - gridX);
                        float y = gridY + (1f * i / VerticalCellCount) * (gridHeight - gridY);
                        particleSystem.AddParticles(new Vector2(x, y));
                    }
                }
            }
            //
            spriteBatch.Begin();
            spriteBatch.DrawString(comicSansFont, string.Format("Numero de generacion: {0}, Celulas vivas: {1}", generationNumber, aliveCellCount),
                new Vector2(8, 8), Color.YellowGreen);
            spriteBatch.End();

        }

        #region Public

        public ContentManager Content
        {
            get { return content; }
        }


        public SpriteBatch SpriteBatch
        {
            get { return spriteBatch; }
        }

        public static Random Random
        {
            get { return random; }
        }

        #endregion

        #region Helper Functions

        //  a handy little function that gives a random float between two
        // values. This will be used in several places in the sample, in particilar in
        // ParticleSystem.InitializeParticle.
        public static float RandomBetween(float min, float max)
        {
            return min + (float)random.NextDouble() * (max - min);
        }

        #endregion

        #region Private

        private bool TestBornCondition(int i, int j)
        {
            //Obtenemos las celulas adyacentes a la celula dada
            CellState[] adyacentCells = GetAdjacentCells(i, j);
            //Contamos el n�mero de celulas vivas
            int aliveCells = CountAliveCells(adyacentCells);
            //Comprobamos si dicho n�mero coincide con la condici�n de nacimiento
            foreach (int bornCondition in bornNeighbours)
            {
                if (bornCondition == aliveCells)
                    return true;
            }
            return false;
        }

        private bool TestSurviveCondition(int i, int j)
        {
            //Obtenemos las celulas adyacentes a la celula dada
            CellState[] adyacentCells = GetAdjacentCells(i, j);
            //Contamos el n�mero de celulas vivas
            int aliveCells = CountAliveCells(adyacentCells);
            //Comprobamos si dicho n�mero coincide con la condici�n de nacimiento
            foreach (int stayAliveCondition in stayAliveNeighbours)
            {
                if (stayAliveCondition == aliveCells)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Cuenta el n�mero de celulas vivas de la matriz de estado
        /// </summary>
        /// <param name="stateGrid"></param>
        /// <returns></returns>
        private int CountAliveCells(CellState[,] stateGrid)
        {
            int accumulator = 0;

            for (int i = 0; i < VerticalCellCount; i++)
            {
                for (int j = 0; j < HorizontalCellCount; j++)
                {
                    if (stateGrid[i, j] == CellState.Alive)
                        accumulator++;
                }
            }

            return accumulator;
        }
        /// <summary>
        /// Contamos el n�mero de celulas que tienen el estado de 'viva' en el array suministrado
        /// </summary>
        /// <param name="cells"></param>
        /// <returns></returns>
        private int CountAliveCells(CellState[] cells)
        {
            int accumulator = 0;
            for (int i = 0; i < cells.Length; i++)
            {
                if (cells[i] == CellState.Alive)
                    accumulator++;
            }
            return accumulator;
        }

        /// <summary>
        /// Obtenemos un array de las celulas adyacentes a una celula dada
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <returns></returns>
        private CellState[] GetAdjacentCells(int i, int j)
        {
            int gridWidth = state.GetLength(0);
            int gridHeight = state.GetLength(1);

            List<CellState> adyacentCells = new List<CellState>();
            for (int x = -1; x < 2; x++)
            {
                for (int y = -1; y < 2; y++)
                {
                    //Si no estamos en la celda central es decir si x e y no son ambos 0
                    if (!((x == 0) && (y == 0)))
                    {
                        //Comprobamos que no estamos fuera de rango y de ser as� ajustamos el indice
                        int xIndex = i + x;
                        if (xIndex < 0)
                            xIndex = gridWidth - 1;
                        else if (xIndex >= gridWidth)
                            xIndex = 0;

                        int yIndex = j + y;
                        if (yIndex < 0)
                            yIndex = gridHeight - 1;
                        else if (yIndex >= gridHeight)
                            yIndex = 0;
                        //
                        adyacentCells.Add(state[xIndex, yIndex]);
                    }
                }
            }
            return adyacentCells.ToArray();
        }

        #endregion
    }
}
