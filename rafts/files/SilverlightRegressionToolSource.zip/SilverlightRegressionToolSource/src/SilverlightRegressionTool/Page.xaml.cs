﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Windows.Controls.DataVisualization.Charting;

namespace SilverlightRegressionTool
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();

            App.Current.Host.Content.FullScreenChanged += new EventHandler(Content_FullScreenChanged);
            Loaded += new RoutedEventHandler(Page_Loaded);
            KeyDown += new KeyEventHandler(Page_KeyDown);
        }

        void Content_FullScreenChanged(object sender, EventArgs e)
        {
            if (App.Current.Host.Content.IsFullScreen == true)
            {
                mMessageTextBlock.Text = "Por motivos de seguridad en el modo a pantalla completa no funcionará el teclado";
                mMessagePanel.Visibility = Visibility.Visible;
                mFullScreenButton.IsEnabled = false;
            }
            else
            {
                mMessagePanel.Visibility = Visibility.Collapsed;
                mFullScreenButton.IsEnabled = true;
            }

        }

        void Page_Loaded(object sender, RoutedEventArgs e)
        {
            mInputTextBox.Focus();
        }

        void Page_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                ProcessInputPoints();
        }

        private void mAddDataPointsButton_Click(object sender, RoutedEventArgs e)
        {
            ProcessInputPoints();
        }

        private void mInputTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            EditablePoint p;
            mAddDataPointsButton.IsEnabled = EditablePoint.TryParse(mInputTextBox.Text, out p);

        }

        private void mClearSelectedDataButton_Click(object sender, RoutedEventArgs e)
        {
            var points = mDataGrid.SelectedItems.Cast<EditablePoint>().ToArray();
            for (int i = 0; i < points.Length; i++)
            {
                App.Model.DataPoints.Remove(points[i]);
            }
        }

        void ProcessInputPoints()
        {
            //try to convert
            EditablePoint p;
            if (EditablePoint.TryParse(mInputTextBox.Text, out p) == true)
            {
                EditablePoint existingPoint = App.Model.DataPoints.FirstOrDefault((point) => { return (point.X == p.X); });
                if (existingPoint != null)
                {
                    existingPoint.Y = p.Y;
                }
                else
                {
                    App.Model.DataPoints.Add(p);
                }
                //Get ready to next input
                mInputTextBox.Text = string.Empty;
                mInputTextBox.Focus();
            }
        }


        private void mChart_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var p = e.GetPosition(mFunctionSeries);
        }

        private void mFullScreenButton_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Host.Content.IsFullScreen = true;
        }

        private void mDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            mClearSelectedDataButton.IsEnabled = mDataGrid.SelectedItems.Count > 0;
        }
    }
}
