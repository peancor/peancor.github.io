﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace SilverlightRegressionTool
{
    public class EditablePoint: INotifyPropertyChanged
    {
        readonly static char[] mStringSplitCharacters = { ' ' }; 
        Double mX, mY;

        public Double X
        {
            get { return mX; }
            set { mX = value; SignalPropertyChanged("X"); }
        }

        public Double Y
        {
            get { return mY; }
            set { mY = value; SignalPropertyChanged("Y"); }
        }

        public EditablePoint(Double x, Double y)
        {
            mX = x;
            mY = y;
        }

        public static Boolean TryParse(string s, out EditablePoint result)
        {
            result = null;
            if (String.IsNullOrEmpty(s) == false)
            {
                string[] components = s.Split(mStringSplitCharacters, StringSplitOptions.RemoveEmptyEntries);
                if (components.Length != 2)
                    return false;
                Double x, y;
                bool hasX = Double.TryParse(components[0], out x);
                bool hasY = Double.TryParse(components[1], out y);
                if (hasX && hasY)
                {
                    result = new EditablePoint(x, y);
                    return true;
                }
                else
                    return false;
            }
            return false;
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        void SignalPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
