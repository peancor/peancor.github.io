﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Globalization;
using System.ComponentModel;
using System.Linq;

namespace SilverlightRegressionTool
{
    public class Model : INotifyPropertyChanged
    {
        readonly ObservableCollection<EditablePoint> mDataPoints = new ObservableCollection<EditablePoint>();
        Func<Double, Double> _RegressionFunction;
        UIElement _RegressionFunctionTitle;
        Int32 mSelectedOrderIndex = 0;
        Int32[] mOrdersAllowed = { 1, 2, 3, 4 };
        String mPredictedPoint;


        public ObservableCollection<EditablePoint> DataPoints
        {
            get
            {
                return mDataPoints;
            }
        }

        public Func<Double, Double> RegressionFunction
        {
            get { return _RegressionFunction; }
            private set { _RegressionFunction = value; OnPropertyChanged("RegressionFunction"); }
        }

        public UIElement RegressionFunctionTitle
        {
            get { return _RegressionFunctionTitle; }
            set { _RegressionFunctionTitle = value; OnPropertyChanged("RegressionFunctionTitle"); }
        }

        public Int32 SelectedOrderIndex
        {
            get { return mSelectedOrderIndex; }
            set { mSelectedOrderIndex = value; OnPropertyChanged("SelectedOrderInder"); OnRegressionTypeChanged(); }
        }

        public Int32[] OrdersAllowed
        {
            get { return mOrdersAllowed; }
        }

        public string PredictedPoint
        {
            get { return mPredictedPoint; }
            set { mPredictedPoint = value; OnPropertyChanged("PredictedPoint"); }
        }

        public Model()
        {
            mDataPoints.CollectionChanged += (o, e) => 
                {
                    if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
                    {
                        foreach (INotifyPropertyChanged item in e.NewItems)
                            item.PropertyChanged += (oo,ee) => { OnRegressionTypeChanged(); };
                    }
                    OnRegressionTypeChanged();
                };       
            //
            RegressionFunctionTitle = new TextBlock() {Text = "Introduzca más puntos de datos"};
        }

        void OnEditablePointChanged(object sender, PropertyChangedEventArgs e)
        {
        }


        private void OnRegressionTypeChanged()
        {
            //we need two points at least
            if (mDataPoints.Count < 2)
            {
                RegressionFunction = null;
                RegressionFunctionTitle = new TextBlock() { Text = "Introduzca más puntos de datos" };
                return;
            }
            //
            int dimension = mOrdersAllowed[mSelectedOrderIndex];
            // Initialize a simple least squares analysis
            int i = 0;
            int j = 0;
            int k = 0;
            double[] y = new double[mDataPoints.Count];
            double[,] x = new double[mDataPoints.Count, dimension + 1];
            for (i = 0; i < mDataPoints.Count; i++)
            {
                EditablePoint point = mDataPoints[i];
                double independentValue = Convert.ToDouble(point.X, CultureInfo.InvariantCulture);

                for (j = 0; j <= dimension; j++)
                {
                    x[i, j] = Math.Pow(independentValue, j);
                }

                y[i] = Convert.ToDouble(point.Y, CultureInfo.InvariantCulture);
            }

            // Create the equations
            double[][] matrix = new double[dimension + 1][];
            for (i = 0; i <= dimension; i++)
            {
                // Create the row
                matrix[i] = new double[dimension + 2];

                // indeterminate coefficients
                for (j = 0; j <= dimension; j++)
                {
                    matrix[i][j] = 0.0;
                    for (k = 0; k < mDataPoints.Count; k++)
                    {
                        matrix[i][j] += x[k, i] * x[k, j];
                    }
                }

                // determinate values
                for (k = 0; k < mDataPoints.Count; k++)
                {
                    matrix[i][dimension + 1] += x[k, i] * y[k];
                }
            }

            // Convert to row-echelon form
            i = 0;
            j = 0;
            while (i <= dimension && j <= dimension)
            {
                // Get the pivot in column j starting at row i
                int pivotRow = i;
                for (k = i; k <= dimension; k++)
                {
                    if (Math.Abs(matrix[k][j]) > Math.Abs(matrix[pivotRow][j]))
                    {
                        pivotRow = k;
                    }
                }
                double pivot = matrix[pivotRow][j];

                // If we have a pivot element
                if (pivot != 0)
                {
                    // Swap the current row with the pivot row
                    double[] temp = matrix[i];
                    matrix[i] = matrix[pivotRow];
                    matrix[pivotRow] = temp;
                    pivotRow = i;

                    // Normalize the pivot row to the pivot
                    double c = matrix[i][j];
                    for (k = 0; k <= dimension + 1; k++)
                    {
                        matrix[i][k] /= c;
                    }

                    // Clear out the pivot position from the remaining rows
                    for (k = i + 1; k <= dimension; k++)
                    {
                        c = matrix[k][j];
                        for (int m = i; m <= dimension + 1; m++)
                        {
                            matrix[k][m] -= c * matrix[i][m];
                        }
                    }

                    i++;
                }

                j++;
            }

            // Solve using substitution
            for (i = dimension - 1; i >= 0; i--)
            {
                for (j = dimension; j > i; j--)
                {
                    matrix[i][dimension + 1] -= matrix[i][j] * matrix[j][dimension + 1];
                    matrix[i][j] = 0;
                }
            }

            // Capture the coefficients
            double a0 = matrix[0][dimension + 1];
            double a1 = matrix[1][dimension + 1];
            double a2 = (dimension >= 2) ? matrix[2][dimension + 1] : double.NaN;
            double a3 = (dimension >= 3) ? matrix[3][dimension + 1] : double.NaN;
            double a4 = (dimension == 4) ? matrix[4][dimension + 1] : double.NaN;

            // Create the function
            Func<double, double> function = null;
            switch (dimension)
            {
                case 1:
                    function = z => a1 * z + a0;
                    break;
                case 2:
                    function = z => a2 * z * z + a1 * z + a0;
                    break;
                case 3:
                    function = z => a3 * z * z * z + a2 * z * z + a1 * z + a0;
                    break;
                case 4:
                    function = z => a4 * z * z * z * z + a3 * z * z * z + a2 * z * z + a1 * z + a0;
                    break;
            }

            // Create the title
            StackPanel title = new StackPanel { Orientation = Orientation.Horizontal };
            title.Children.Add(
                new TextBlock
                {
                    Text = "f(x) = ",
                    Margin = new Thickness(0, 4, 0, 0)
                });

            title.Children.Add(
                new TextBlock
                {
                    Text = a0.ToString("N3", CultureInfo.InvariantCulture),
                    Margin = new Thickness(0, 4, 0, 0)
                });
            AddTitleTerm(title, a1, 1);
            if (dimension >= 2)
            {
                AddTitleTerm(title, a2, 2);
            }
            if (dimension >= 3)
            {
                AddTitleTerm(title, a3, 3);
            }
            if (dimension == 4)
            {
                AddTitleTerm(title, a4, 4);
            }

            // Set the function and the title
            RegressionFunction = function;
            RegressionFunctionTitle = title;
        }

        private static void AddTitleTerm(StackPanel title, double value, int exponent)
        {
            if (value == 0)
            {
                return;
            }

            title.Children.Add(
                new TextBlock
                {
                    Text = value >= 0 ? " + " : " - ",
                    Margin = new Thickness(0, 4, 0, 0)
                });
            title.Children.Add(
                new TextBlock
                {
                    Text = string.Format(CultureInfo.InvariantCulture, "{0:N3}x", Math.Abs(value)),
                    Margin = new Thickness(0, 4, 0, 0)
                });

            if (exponent > 1)
            {
                title.Children.Add(
                    new TextBlock
                    {
                        Text = exponent.ToString(CultureInfo.InvariantCulture),
                        FontSize = 8
                    });
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
