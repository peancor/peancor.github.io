﻿///<reference path="jquery-1.4.1-vsdoc.js" />
var debugMode = false;
var debugCount = 0;
/*if (debugMode == true) {
    var System = new Object();
    System.Gadget = new Object();
    System.Gadget.docked = false;
}*/
//Suscripción a eventos
System.Gadget.onDock = dockStateChanged;
System.Gadget.onUndock = dockStateChanged;
//
var isVisualizationApiLoaded = false;
//
var sampleCount = 50;
var datetimeArray = new Array(sampleCount);
var temperatureArray = new Array(sampleCount);
var humidityArray = new Array(sampleCount);
var chartCreated = false;
var chart;
var chartData;
var measuredReceivedCount = 0;

//Valores maximos,minimos, medios
var minTemp = Infinity;
var maxTemp = -Infinity;
var meanTemp = Infinity;
var minHumidity = Infinity;
var maxHumidity = -Infinity;
var meanHumidity = Infinity;
//Valores de escala del grafico
var minChartY = -5;
var maxChartY = 75;

//iniciamos los arrays
for (i = 0; i < sampleCount; i++) {
    datetimeArray[i] = "";
    temperatureArray[i] = 0;
    humidityArray[i] = 0;
}
//cargamos la visualizacion de google
//google.load("visualization", "1", { packages: ["linechart"] });
//google.setOnLoadCallback(createChart);

$(document).ready(function() {
    //Cargamos las apis de visualizacion
    loadVisualizationApi();
    //Establecemos el tamaño inicial
    dockStateChanged();
    //Establecemos el timer
    setInterval(timerTick, 60000);
    //Ejecutamos el timer en 0
    timerTick(0);
});

function timerTick(elapsed) {
    //Obtenemos la temperatura y la humedad
    $.ajax({
        url: 'http://localhost:8080/?q=g',
        cache: false,
        dataType: 'text',
        success: measureReceived
    });
    //
    if (debugMode) {
        debugCount++;
        if (debugCount % 5 == 0) {
            System.Gadget.docked = !System.Gadget.docked;
            dockStateChanged();
        }
    }
}

// called when the docked state changes
function dockStateChanged() {
    if (System.Gadget.docked) {
        //Eliminamos el gráfico
        $("#chart").html("");
        chartCreated = false;
        System.Gadget.background = "background.png";
        document.body.style.width = "126px";
        document.body.style.height = "204px";
    } else {
        System.Gadget.background = "background-undocked.png";
        document.body.style.width = "380px";
        document.body.style.height = "205px";
        //creamos el grafico
        if (isVisualizationApiLoaded) {
            createChart();
        }
    }
}

function measureReceived(measureString, extStatus, XMLHttpRequest) {
    //Extraemos la medida
    splitted = measureString.split("|");
    var currentTemperature = parseFloat(splitted[0]);
    var currentHumidity = parseFloat(splitted[1]);
    //Calculamos estadisticos
    if (currentTemperature < minTemp) minTemp = currentTemperature;
    if (currentTemperature > maxTemp) maxTemp = currentTemperature;
    if (currentHumidity < minHumidity) minHumidity = currentHumidity;
    if (currentHumidity > maxHumidity) maxHumidity = currentHumidity;
    if (measuredReceivedCount == 0) {
        meanTemp = currentTemperature;
        meanHumidity = currentHumidity;
    }
    else {
        meanTemp = meanTemp + ((currentTemperature - meanTemp) / (measuredReceivedCount + 1));
        meanHumidity = meanHumidity + ((currentHumidity - meanHumidity) / (measuredReceivedCount + 1));
    }
    //Actualizamos la escala del grafico
    minChartY = minTemp - 5;
    maxChartY = maxHumidity + 5;
    //
    $("#temperatureCurrent").html(currentTemperature.toFixed(1).toString() + "ºC");
    $("#temperatureMin").html(minTemp.toFixed(0).toString() + "ºC");
    $("#temperatureMean").html(minTemp.toFixed(0).toString() + "ºC");
    $("#temperatureMax").html(maxTemp.toFixed(0).toString() + "ºC");
    $("#humidityCurrent").html(currentHumidity.toFixed(0).toString() + "%");
    $("#humidityMin").html(minHumidity.toFixed(0).toString() + "%");
    $("#humidityMean").html(meanHumidity.toFixed(0).toString() + "%");
    $("#humidityMax").html(maxHumidity.toFixed(0).toString() + "%");
    //
    if (measuredReceivedCount < sampleCount) {
        //establecemos los nuevos valores
        var now = new Date();
        datetimeArray[measuredReceivedCount] = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
        temperatureArray[measuredReceivedCount] = currentTemperature;
        humidityArray[measuredReceivedCount] = currentHumidity;
    }
    else {
        //Desplazamos los valores
        for (i = 0; i < sampleCount - 1; i++) {
            datetimeArray[i] = datetimeArray[i + 1];
            humidityArray[i] = humidityArray[i + 1];
            temperatureArray[i] = temperatureArray[i + 1];
        }
        //establecemos los nuevos valores
        var now = new Date();
        datetimeArray[sampleCount - 1] = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
        temperatureArray[sampleCount - 1] = currentTemperature;
        humidityArray[sampleCount - 1] = currentHumidity;
    }
    //Actualizamos el grafico
    measuredReceivedCount++;
    if (System.Gadget.docked == false) {
        if (chartCreated) {
            updateChart();
        }
    }
}

function temperatureReceived(temperature) {
    //Desplazamos los valores de temperatura
    for (i = 0; i < sampleCount - 1; i++) {
        temperatureArray[i] = temperatureArray[i + 1];
    }
    //establecemos el nuevo valor
    temperatureArray[sampleCount - 1] = parseFloat(temperature);
}

function humidityReceived(humidity) {
    //Desplazamos los valores de humedad
    for (i = 0; i < sampleCount - 1; i++) {
        humidityArray[i] = humidityArray[i + 1];
    }
    //establecemos el nuevo valor
    humidityArray[sampleCount - 1] = parseFloat(humidity);
}

function loadVisualizationApi() {
    if (isVisualizationApiLoaded == false) {
        google.load("visualization", "1", { packages: ["linechart"], callback: function() {
            isVisualizationApiLoaded = true;
            if (System.Gadget.docked == false) {
                createChart();
            }
        }
        });
    }
}

function createChart() {
    //Si el gráfico ya ha sido creado no hacemos nada
    if (chartCreated == true) {
        return;
    }
    chart = new google.visualization.LineChart(document.getElementById('chart'));
    chartData = new google.visualization.DataTable();
    chartData.addColumn('string', 'Hora');
    chartData.addColumn('number', 'Temperatura');
    chartData.addColumn('number', 'humedad');
    chartData.addRows(sampleCount);
    //
    chartCreated = true;
}

function updateChart() {

    for (i = 0; i < sampleCount; i++) {
        chartData.setValue(i, 0, datetimeArray[i]);
        chartData.setValue(i, 1, temperatureArray[i]);
        chartData.setValue(i, 2, humidityArray[i]);
    }
    chart.draw(chartData, { width: 230, height: 180, legend: 'none', min: minChartY, max: maxChartY, backgroundColor: 'White' });
}
