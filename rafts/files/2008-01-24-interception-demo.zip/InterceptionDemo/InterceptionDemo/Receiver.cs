﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.Core;

namespace InterceptionDemo
{
    [Interceptor(typeof(ParentalControlInterceptor))]
    public class Receiver
    {
        public void WaitMessages()
        {
            while (true)
            {
                Console.Write("Escriba un mensaje: ");
                string message = Console.ReadLine();
                if (message == "exit" || message == "quit")
                    break;
                OnMessageReceived(message);
            }
        }

        protected virtual void OnMessageReceived(string message)
        {
            Console.WriteLine("Mensaje recibido: " + message);
        }
    }
}
