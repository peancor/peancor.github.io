﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.Core.Interceptor;

namespace InterceptionDemo
{
    public class ParentalControlInterceptor: IInterceptor
    {
        #region IInterceptor Members

        public void Intercept(IInvocation invocation)
        {
            if (invocation.Method.Name == "OnMessageReceived")
            {
                Console.WriteLine("Mensaje interceptado: "
                    + invocation.Arguments[0].ToString());
                Console.Write("¿Aprueba el envío de este mensage (s/n)?");
                string response = Console.ReadLine();
                if (response.ToUpper().StartsWith("S"))
                    invocation.Proceed();
            }
        }

        #endregion
    }
}
