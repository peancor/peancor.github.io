﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.Windsor;

namespace InterceptionDemo
{
    class Program
    {
        static IWindsorContainer container;

        static void Main(string[] args)
        {
            container = new WindsorContainer();

            container.AddComponent<ParentalControlInterceptor>();
            container.AddComponent<Receiver>();

            Receiver receiver = container.Resolve<Receiver>();
            receiver.WaitMessages();
        }
    }
}
