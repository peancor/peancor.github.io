using System;
using System.Collections.Generic;
using System.Text;

namespace Diamond
{
    public class DiamondSquareOld
    {
        float[,] mDataGrid;
        int mGridSize;
        int mIterationCount = 1;
        int mMidSize;

        public DiamondSquareOld(int maxIterations, float topLeft,
            float topRight, float bottomLeft, float bottomRight)
        {
            mMidSize = (int)Math.Pow(2, maxIterations);
            mGridSize = 2 * mMidSize + 1;
            mDataGrid = new float[mGridSize, mGridSize];
            //establecemos la altura inicial de las esquinas de la rejilla
            mDataGrid[0, 0] = topLeft;
            mDataGrid[mGridSize - 1, 0] = topRight;
            mDataGrid[0, mGridSize - 1] = bottomLeft;
            mDataGrid[mGridSize - 1, mGridSize - 1] = bottomRight;
        }

        public void Step()
        {   
            //
            //Diamond step
            //
            //para cada punto medio de cada rectangulo
            int rectangleMidSize = mMidSize / mIterationCount;
            for (int y = rectangleMidSize; y < mGridSize; y += rectangleMidSize)
            {
                for (int x = rectangleMidSize; x < mGridSize; x += rectangleMidSize)
                {
                    //Calculamos las coordenadas de cada punto del rectangulo
                    float rtl = mDataGrid[x - rectangleMidSize / 2, y - rectangleMidSize / 2];
                    float rtr = mDataGrid[x + rectangleMidSize / 2, y - rectangleMidSize / 2];
                    float rbl = mDataGrid[x - rectangleMidSize / 2, y + rectangleMidSize / 2];
                    float rbr = mDataGrid[x + rectangleMidSize / 2, y + rectangleMidSize / 2];
                    //calculamos el punto medio
                    float midPoint = (rtl + rtr + rbl + rbr) / 4;
                    //y le establecemos

                    //Calculamos los cuatro puntos de la nueva subdivision
                    mDataGrid[x - rectangleMidSize / 2, y] = (rtl + rbl) / 2; //left
                    mDataGrid[x, y - rectangleMidSize / 2] = (rtl + rtr) / 2; //top
                    mDataGrid[x + rectangleMidSize / 2, y] = (rtr + rbr) / 2; //right
                    mDataGrid[x, y + rectangleMidSize / 2] = (rbl + rbr) / 2; //bottom
                }
            }
            //
            //Square step
            //
            for (int y = rectangleMidSize; y < mGridSize; y += rectangleMidSize)
            {
                for (int x = rectangleMidSize; x < mGridSize; x += rectangleMidSize)
                {
                    //Calculamos las coordenadas de cada punto del rectangulo
                    float rtl = mDataGrid[x - rectangleMidSize / 2, y - rectangleMidSize / 2];
                    float rtr = mDataGrid[x + rectangleMidSize / 2, y - rectangleMidSize / 2];
                    float rbl = mDataGrid[x - rectangleMidSize / 2, y + rectangleMidSize / 2];
                    float rbr = mDataGrid[x + rectangleMidSize / 2, y + rectangleMidSize / 2];
                    //calculamos el punto medio
                    float midPoint = (rtl + rtr + rbl + rbr) / 4;
                }
            }

            

        }
    }
}
