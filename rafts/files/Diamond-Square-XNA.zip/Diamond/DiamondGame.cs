using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Diamond
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class DiamondGame : Microsoft.Xna.Framework.Game
    {
        DiamondSquareGrid mDiamondSquareGrid;
        BasicEffect mBasicEffect;
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        GridMesh mGrid;
        Matrix mView, mProjection;
        
        Single mPhi;
        bool mIsSpaceKeyDown = false;

        public DiamondGame()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.PreferredBackBufferWidth = 400;
            graphics.PreferredBackBufferHeight = 300;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            mView = Matrix.CreateLookAt(new Vector3(0, 200, 400), Vector3.Zero, Vector3.Up);
            mProjection = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, 4.0f / 3.0f, 1, 1000);

            BasicEffect effect = new BasicEffect(GraphicsDevice, null);
            effect.EnableDefaultLighting();
            effect.DiffuseColor = Color.BlueViolet.ToVector3();
            effect.SpecularColor = Color.Brown.ToVector3();
            effect.World = Matrix.Identity;
            effect.View = mView;
            effect.Projection = mProjection;
            mBasicEffect = effect;

            /*this.IsFixedTimeStep = true;
            this.TargetElapsedTime = TimeSpan.FromSeconds(1);
            */
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            mDiamondSquareGrid = new DiamondSquareGrid(128, 500, 1.25f);
            mDiamondSquareGrid.Run();

            mGrid = new GridMesh(this, Vector3.Zero, Vector3.Up, Vector3.Backward,
                300, 300, mDiamondSquareGrid.Data);

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();
            //
            if (Keyboard.GetState().IsKeyDown(Keys.Space))
            {
                mIsSpaceKeyDown = true;
            }
            else if (mIsSpaceKeyDown==true)
            {                
                mIsSpaceKeyDown = false;
                mDiamondSquareGrid = new DiamondSquareGrid(128, 500, 1.25f);
                mDiamondSquareGrid.Run();
                mGrid = new GridMesh(this, Vector3.Zero, Vector3.Up, Vector3.Backward,
                    300, 300, mDiamondSquareGrid.Data);
            }

            // TODO: Add your update logic here
            /*if (mDiamondSquareGrid.Step() == true)
            {
                mGrid.Update();
            };*/
            mPhi = mPhi + (Single)((2 * Math.PI / 6) * gameTime.ElapsedGameTime.TotalSeconds);
            mBasicEffect.World = Matrix.CreateRotationY(mPhi);

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.Black);

            GraphicsDevice.VertexDeclaration = new VertexDeclaration(GraphicsDevice,
                VertexPositionNormalTexture.VertexElements);

            mBasicEffect.Begin();
            // TODO: Add your drawing code here
            foreach (EffectPass pass in mBasicEffect.CurrentTechnique.Passes)
            {
                pass.Begin();
                GraphicsDevice.DrawUserIndexedPrimitives<VertexPositionNormalTexture>(PrimitiveType.TriangleList,
                    mGrid.Points, 0, mGrid.Points.Length, mGrid.Indexes, 0, mGrid.Indexes.Length / 3);
                pass.End();
                
            }
            mBasicEffect.End();
            
            base.Draw(gameTime);
        }
    }
}
