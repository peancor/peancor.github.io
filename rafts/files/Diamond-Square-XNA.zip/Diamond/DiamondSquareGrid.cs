using System;
using System.Collections.Generic;
using System.Text;

namespace Diamond
{
    public class DiamondSquareGrid
    {
        Random mRandom;
        int mSuperSize; //Tama�o
        int mSize;    //
        int mMaxIterations, mIterationCount;
        Single[,] mData;
        Single mRatio, mScale;
        Int32 mStride;

        public Single[,] Data
        {
            get { return mData; }
        }

        public DiamondSquareGrid(int size, Single heightScale, float h)
        {
            if (IsPowerOf2(size) == false)
                throw new ArgumentOutOfRangeException("size");

            mSize = size;
            mSuperSize = size + 1;
            mMaxIterations = (Int32)Math.Log(mSize, 2);
            mData = new Single[mSuperSize, mSuperSize];
            //
            mRatio = (Single)Math.Pow(2.0, -h);
            mScale = heightScale * mRatio;
            mStride = size / 2;
            mData[0, 0] = mData[size, size] = mData[size, 0] = mData[0, size] = 0.0f;

            mRandom = new Random();
        }

        public void Run()
        {
            while (Step()==true) ;
        }

        public Boolean Step()
        {
            if (mStride == 0)
                return false;

            /* Take the existing "square" data and produce "diamond"
               data. On the first pass through with a 4x4 matrix, the
               existing data is shown as "X"s, and we need to generate the
               "*" now:

                   X   .   .   .   X

                   .   .   .   .   .

                   .   .   *   .   .

                   .   .   .   .   .

                   X   .   .   .   X

              It doesn't look like diamonds. What it actually is, for the
              first pass, is the corners of four diamonds meeting at the
              center of the array. */
            for (int i = mStride; i < mSize; i += mStride)
            {
                for (int j = mStride; j < mSize; j += mStride)
                {
                    mData[j, i] = mScale * GetRandomNumber(-0.5f, 0.5f) + AverageSquareValues(i, j,
                        mStride, mSize, mSuperSize, mData);
                    j += mStride;
                }
                i += mStride;
            }

            /* Take the existing "diamond" data and make it into
       "squares". Back to our 4X4 example: The first time we
       encounter this code, the existing values are represented by
       "X"s, and the values we want to generate here are "*"s:

           X   .   *   .   X

           .   .   .   .   .

           *   .   X   .   *

           .   .   .   .   .

           X   .   *   .   X

       i and j represent our (x,y) position in the array. The
       first value we want to generate is at (i=2,j=0), and we use
       "oddline" and "stride" to increment j to the desired value.
       */
            bool oddline = false;
            for (int i = 0; i < mSize; i += mStride)
            {
                oddline = !oddline;
                for (int j = 0; j < mSize; j += mStride)
                {
                    if ((oddline) && (j == 0)) j += mStride;

                    /* i and j are setup. Call avgDiamondVals with the
                       current position. It will return the average of the
                       surrounding diamond data points. */
                    mData[j, i] = mScale * GetRandomNumber(-0.5f, 0.5f) + AverageDiamondValues(i, j,
                        mStride, mSize, mSuperSize, mData);

                    /* To wrap edges seamlessly, copy edge values around
                       to other side of array */
                    if (i == 0)
                        mData[j, mSize] = mData[j, 0];
                    if (j == 0)
                        mData[mSize, i] = mData[0, i];

                    j += mStride;
                }
            }
            //
            mScale *= mRatio;
            mStride /= 2;
            return true;
        }

        Single AverageDiamondValues(int i, int j, int stride, int size, int superSize, Single[,] data)
        {
            /* In this diagram, our input stride is 1, the i,j location is
               indicated by "X", and the four value we want to average are
               "*"s:
                   .   *   .

                   *   X   *

                   .   *   .
               */

            /* In order to support tiled surfaces which meet seamless at the
               edges (that is, they "wrap"), We need to be careful how we
               calculate averages when the i,j diamond center lies on an edge
               of the array. The first four 'if' clauses handle these
               cases. The final 'else' clause handles the general case (in
               which i,j is not on an edge).
             */
            if (i == 0)
                return (data[j - stride, i] + data[j + stride, i] + data[j, size - stride] + data[j, i + stride]) * 0.25f;
            else if (i == size)
                return (data[j - stride, i] + data[j + stride, i] + data[j, i - stride] + data[j, stride]) * 0.25f;
            else if (j == 0)
                return (data[j, i - stride] + data[j, i + stride] + data[j + stride, i] + data[size - stride, i]) * 0.25f;
            else if (j == size)
                return (data[j, i - stride] + data[j, i + stride] + data[j - stride, i] + data[stride, i]) * 0.25f;
            else
                return (data[j, i - stride] + data[j, i + stride] + data[j - stride, i] + data[j + stride, i]) * 0.25f;
        }

        Single AverageSquareValues(int i, int j, int stride, int size, int superSize, Single[,] data)
        {    
            /* In this diagram, our input stride is 1, the i,j location is
               indicated by "*", and the four value we want to average are
               "X"s:
                   X   .   X

                   .   *   .

                   X   .   X
               */
            return (  data[j - stride, i - stride] 
                    + data[j + stride, i - stride]
                    + data[j - stride, i + stride]
                    + data[j + stride, i + stride]) * 0.25f;
        }


        Boolean IsPowerOf2(Int32 val)
        {
            return (val & (val - 1)) == 0;
        }

        Single GetRandomNumber(Single min, Single max)
        {
            double range = max - min;
            return (Single)(min + range * mRandom.NextDouble());
        }
    }
}
