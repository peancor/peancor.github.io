using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Diamond
{
    public class GridMesh : DrawableGameComponent
    {
        Vector3 mOrigin, mNormal, mUp;
        Single mWidth, mHeight;
        Single[,] mHeightMap;
        VertexPositionNormalTexture[] mPointArray;
        int[] mIndexes;

        public VertexPositionNormalTexture[] Points
        {
            get { return mPointArray; }
        }

        public int[] Indexes
        {
            get { return mIndexes; }
        }

        public GridMesh(Game game, Vector3 origin, Vector3 normal,
            Vector3 up, Single width, Single height, Single[,] heightMap)
            : base(game)
        {
            mOrigin = origin;
            mNormal = normal;
            mUp = up;
            mHeightMap = heightMap;
            mWidth = width;
            mHeight = height;
            mPointArray = new VertexPositionNormalTexture[heightMap.GetLength(0) * heightMap.GetLength(1)];
            CreateMesh();
        }

        public void Update()
        {
            CreateMesh();
        }

        void CreateMesh()
        {
            //Calculamos la esquinas
            Vector3 left = Vector3.Cross(mNormal, mUp);
            Vector3 upperCenter = (mUp * mHeight / 2) + mOrigin;
            Vector3 upperLeft = upperCenter + (mWidth / 2 * left);
            Vector3 upperRight = upperCenter - (mWidth / 2 * left);
            Vector3 lowerLeft = upperLeft - (mUp * mHeight);
            Vector3 lowerRight = upperRight - (mUp * mHeight);
            //
            int pWidth = mHeightMap.GetLength(0);
            int pHeight = mHeightMap.GetLength(1);
            Single widthStep = mWidth / (pWidth - 1.0f);
            Single heightStep = mHeight / (pHeight - 1.0f);


            int currentIndex = 0;
            for (int y = 0; y < pHeight; y++)
            {
                for (int x = 0; x < pWidth; x++)
                {
                    mPointArray[currentIndex].Position = upperLeft - x * widthStep * left - y * heightStep * mUp + mHeightMap[x, y] * mNormal;
                    mPointArray[currentIndex].TextureCoordinate = new Vector2(x / (pWidth - 1.0f), y / (pHeight - 1.0f));
                    currentIndex++;
                }
            }
            
            mIndexes = new int[(pHeight - 1) * (pWidth - 1) * 6];

            currentIndex = 0;
            for (int y = 1; y < pHeight; y++)
            {
                for (int x = 0; x < pWidth - 1; x++)
                {
                    mIndexes[currentIndex++] = x + y * pHeight;
                    mIndexes[currentIndex++] = x + (y - 1) * pHeight;
                    mIndexes[currentIndex++] = (x + 1) + (y - 1) * pHeight;

                    mIndexes[currentIndex++] = x + y * pHeight;
                    mIndexes[currentIndex++] = (x + 1) + (y - 1) * pHeight;
                    mIndexes[currentIndex++] = (x + 1) + y * pHeight;
                }
            }

            //
            //normales
            //
            for (int i = 0; i < mPointArray.Length; i++)
            {
                mPointArray[i].Normal = Vector3.Zero;
            }
            for (int i = 0; i < mIndexes.Length; i+=3)
            {
                int index1 = mIndexes[i];
                int index2 = mIndexes[i + 1];
                int index3 = mIndexes[i + 2];

                Vector3 side1 = mPointArray[index1].Position - mPointArray[index3].Position;
                Vector3 side2 = mPointArray[index1].Position - mPointArray[index2].Position;
                Vector3 normal = Vector3.Cross(side1, side2);

                mPointArray[index1].Normal += normal;
                mPointArray[index2].Normal += normal;
                mPointArray[index3].Normal += normal;
            }
            for (int i = 0; i < mPointArray.Length; i++)
            {
                mPointArray[i].Normal = Vector3.Normalize(mPointArray[i].Normal);
            }
        }
    }
}
