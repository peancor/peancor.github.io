﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace LSystems
{
    public partial class LSystemViewer : UserControl
    {
        public static readonly DependencyProperty LSystemProperty = DependencyProperty.Register("LSystem",
            typeof(LSystem), typeof(LSystemViewer), new PropertyMetadata(OnDependencyPropertyChanged));

        Path mPath;


        public LSystem LSystem
        {
            get { return (LSystem)GetValue(LSystemProperty); }
            set { SetValue(LSystemProperty, value); }
        }

        public LSystemViewer()
        {
            InitializeComponent();
            mCanvas.SizeChanged += new SizeChangedEventHandler(mCanvas_SizeChanged);
        }

        void mCanvas_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (mPath != null)
            {
                TransformGroup tg = new TransformGroup();
                tg.Children.Add(new TranslateTransform()
                {
                    X = -mPath.Data.Bounds.Left,
                    Y = -mPath.Data.Bounds.Top
                });
                tg.Children.Add(new ScaleTransform()
                {
                    ScaleX = mCanvas.ActualWidth / mPath.Data.Bounds.Width,
                    ScaleY = mCanvas.ActualHeight / mPath.Data.Bounds.Height
                });
                mPath.RenderTransform = tg;
            }
        }

        void Reset()
        {
            
        }

        void UpdateView()
        {
        }

        static void OnDependencyPropertyChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            LSystemViewer viewer = (LSystemViewer)sender;
            if (e.Property == LSystemProperty)
            {
                viewer.DataContext = e.NewValue;
                viewer.mCanvas.Children.Clear();
                if (e.NewValue != null)
                {
                    viewer.LSystem.AdvanceTo(viewer.LSystem.OptimalGeneration);
                    viewer.mPath = viewer.LSystem.Compose();
                    viewer.mPath.Stroke = new SolidColorBrush(Colors.Black);
                    viewer.mPath.StrokeThickness = 1;
                    viewer.mCanvas.Children.Add(viewer.mPath);
                }
                
            }
        }

        private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            //UpdateView();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void mExitButton_Click(object sender, RoutedEventArgs e)
        {
            App.Model.SelectedContent = new StartView();
        }
    }
}
