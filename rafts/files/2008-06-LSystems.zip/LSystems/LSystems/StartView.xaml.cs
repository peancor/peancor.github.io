﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace LSystems
{
    public partial class StartView : UserControl
    {
        public StartView()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(StartView_Loaded);
        }

        void StartView_Loaded(object sender, RoutedEventArgs e)
        {
            TitleStoryBoard.Begin();
        }

        private void mSierpinskiButton_Click(object sender, RoutedEventArgs e)
        {
            LSystem fp = new SierpinkskiTriangle();
            LSystemViewer viewer = new LSystemViewer();
            //mcontentPresenter.Content = viewer;
            viewer.LSystem = fp;
            App.Model.SelectedContent = viewer;
        }

        private void mPlantButton_Click(object sender, RoutedEventArgs e)
        {
            LSystem ls = null;
            if (e.OriginalSource == mPlantBButton)
                ls = new PlantTypeB();
            else if (e.OriginalSource == mPlantCButton)
                ls = new PlantTypeC();
            else if (e.OriginalSource == mPlantEButton)
                ls = new PlantTypeE();
            else
                ls = new PlantTypeF();
            LSystemViewer viewer = new LSystemViewer();
            //mcontentPresenter.Content = viewer;
            viewer.LSystem = ls;
            App.Model.SelectedContent = viewer;
        }

        private void mDragonCurve_Click(object sender, RoutedEventArgs e)
        {
            LSystem fp = new  DragonCurve();
            LSystemViewer viewer = new LSystemViewer();
            //mcontentPresenter.Content = viewer;
            viewer.LSystem = fp;
            App.Model.SelectedContent = viewer;
        }
    }
}
