﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;

namespace LSystems
{
    /// <summary>
    /// Implements the INotifyPropertyChanged interface and 
    /// exposes PropertyChange method for derived classes 
    /// to rise the PropertyChanged event. 
    /// </summary>
    /// From http://joshsmithonwpf.wordpress.com/2007/08/29/a-base-class-which-implements-inotifypropertychanged/
    public class BindableObjectBase : INotifyPropertyChanged
    {
        private const string ERROR_MSG = "{0} is not a public property of {1}";

        ///<summary>
        ///Occurs when a property value changes.
        ///</summary>
        //[field: NonSerialized]
        public event PropertyChangedEventHandler PropertyChanged;

        protected void SignalPropertyChange(string property)
        {
            VerifyProperty(property);

            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(property));
        }

        [Conditional("DEBUGA")]
        private void VerifyProperty(string propertyName)
        {
            Type type = GetType();

            PropertyInfo propInfo = type.GetProperty(propertyName);

            if (propInfo == null)
            {
                string msg = string.Format(ERROR_MSG, propertyName, type.FullName);
                Debug.Assert(false,msg);
            }
        }
    }
}