﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace LSystems
{
    public class PlantTypeE: LSystem
    {
        public PlantTypeE()
        {
            Name = "Planta tipo E";
            Turtle = new Turtle(new TurtleState(new Point(0, 0),
                new Point(0, 5), 25.7, new SolidColorBrush(Colors.Black)));
            //
            Axiom = "X";
            //
            Productions['X'] = "F[+X][-X]FX";
            Productions['F'] = "FF";
            //
            Actions['F'] = TurtleAction.ForwardAndDraw;
            Actions['-'] = TurtleAction.TurnLeft;
            Actions['+'] = TurtleAction.TurnRight;
            Actions['['] = TurtleAction.StartBranch;
            Actions[']'] = TurtleAction.CompleteBranch;
            //
            OptimalGeneration = 7;
        }
    }
}
