﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace LSystems
{
    public class SierpinkskiTriangle : LSystem
    {
        public SierpinkskiTriangle()
        {
            Name = "Triangulo de sierpikski";
            OptimalGeneration = 8;
            Turtle = new Turtle(new TurtleState(new Point(0, 0),
                new Point(5, 0), 60, new SolidColorBrush(Colors.Black)));
            //
            Axiom = "A";
            //
            Productions['A'] = "B-A-B";
            Productions['B'] = "A+B+A";
            //
            Actions['A'] = TurtleAction.ForwardAndDraw;
            Actions['B'] = TurtleAction.ForwardAndDraw;
            Actions['-'] = TurtleAction.TurnRight;
            Actions['+'] = TurtleAction.TurnLeft;
            Actions['['] = TurtleAction.StartBranch;
            Actions[']'] = TurtleAction.CompleteBranch;
        }
    }
}
