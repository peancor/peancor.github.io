﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace LSystems
{
    public class DragonCurve : LSystem
    {
        public DragonCurve()
        {
            Turtle = new Turtle(new TurtleState(new Point(0, 0),
                new Point(5, 5), 90, new SolidColorBrush(Colors.Black)));
            //
            Axiom = "FX";
            //
            Productions['X'] = "X+YF+";
            Productions['Y'] = "-FX-Y";
            //
            Actions['F'] = TurtleAction.ForwardAndDraw;
            Actions['-'] = TurtleAction.TurnLeft;
            Actions['+'] = TurtleAction.TurnRight;
            Actions['['] = TurtleAction.StartBranch;
            Actions[']'] = TurtleAction.CompleteBranch;

            OptimalGeneration = 12;
        }
    }
}
