﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Text;

namespace LSystems
{
    public enum TurtleAction
    {
        ForwardAndDraw,
        ForwardWithoutDrawing,
        TurnLeft,
        TurnRight,
        StartBranch,
        CompleteBranch,
    }

    public abstract class LSystem: BindableObjectBase
    {
        string mName;
        Turtle mTurtle;
        string mAxiom;
        string mDerivation;
        int mGenerationNumber;
        int mOptimalGeneration = 1;
        
        Dictionary<char, string> mProductions = new Dictionary<char, string>();
        Dictionary<char, TurtleAction> mActionsDictionary = new Dictionary<char, TurtleAction>();

        protected string Axiom
        {
            get { return mAxiom; }
            set { mAxiom = value; }
        }

        protected Dictionary<char, string> Productions
        {
            get { return mProductions; }
        }

        protected Dictionary<char, TurtleAction> Actions
        {
            get { return mActionsDictionary; }
        }

        protected Turtle Turtle
        {
            get { return mTurtle; }
            set { mTurtle = value; }
        }

        public string Name
        {
            get { return mName; }
            set { mName = value; SignalPropertyChange("Name"); }
        }

        public int OptimalGeneration
        {
            get { return mOptimalGeneration; }
            protected set { mOptimalGeneration = value; }
        }

        protected LSystem()
        {
           
        }

        public string Derivation
        {
            get { return mDerivation; }
        }

        public void AdvanceTo(int generationNumber)
        {
            while (mGenerationNumber != generationNumber)
                Generate();
        }

        /// <summary>
        /// Avanza el sistema una generación
        /// </summary>
        /// <returns></returns>
        public void Generate()
        {
            if (mDerivation == null)
                mDerivation = mAxiom;

            StringBuilder sb = new StringBuilder();

            foreach (char c in mDerivation)
            {
                if (Productions.ContainsKey(c))
                    sb.Append(Productions[c]);
                else
                    sb.Append(c);
            }
            mDerivation = sb.ToString();
            mGenerationNumber++;
        }

        public Path Compose()
        {
            Path path = new Path();
            PathFigure figure = new PathFigure();
            mTurtle.Reset();
            
            foreach (char symbol in mDerivation)
            {
                if (Actions.ContainsKey(symbol))
                {
                    mTurtle.Advance(Actions[symbol]);
                }
            }
            path.Data = mTurtle.Geometry;
            return path;
        } 
    }
}
