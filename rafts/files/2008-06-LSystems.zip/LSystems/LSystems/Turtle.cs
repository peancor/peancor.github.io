﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace LSystems
{
    public class Turtle
    {
        TurtleState mInitialState;
        Stack<TurtleState> mStateStack;
        TurtleState mState;
        GeometryGroup mGeometryGroup;

        public GeometryGroup Geometry
        {
            get { return mGeometryGroup; }
        }

        public Turtle(TurtleState initialState)
        {
            mInitialState = initialState;
            Reset();
        }

        public void Reset()
        {
            mStateStack = new Stack<TurtleState>();
            mState = mInitialState;
            mGeometryGroup = new GeometryGroup();
        }

        public void Advance(TurtleAction action)
        {
            switch (action)
            {
                case TurtleAction.ForwardAndDraw:
                    //Añadimos una linea
                    Point startPoint = mState.Location;
                    mState.Advance();
                    LineGeometry line = new LineGeometry()
                    {
                        StartPoint = startPoint,
                        EndPoint = mState.Location,
                    };
                    mGeometryGroup.Children.Add(line);
                    break;
                case TurtleAction.ForwardWithoutDrawing:
                    mState.Advance();
                    break;
                case TurtleAction.TurnLeft:
                    mState.RotateLeft();
                    break;
                case TurtleAction.TurnRight:
                    mState.RotateRight();
                    break;
                case TurtleAction.StartBranch:
                    mStateStack.Push(mState.Clone());
                    break;
                case TurtleAction.CompleteBranch:
                    mState = mStateStack.Pop();
                    break;
            }
        }
    }
}
