﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace LSystems
{
    public class TurtleState
    {
        Point mLocation;
        Point mOrientation;
        Brush mStrokeBrush;
        Double mDeltaAngle;

        /// <summary>
        /// Punto en el que se encuentra la tortuga
        /// </summary>
        public Point Location
        {
            get { return mLocation; }
            set { mLocation = value; }
        }
        /// <summary>
        /// Vector normal representando la orientación
        /// </summary>
        public Point Orientation
        {
            get { return mOrientation; }            
        }

        public double DeltaAngle
        {
            get { return mDeltaAngle; }
            set { mDeltaAngle = value; }
        }

        public Brush StrokeBrush
        {
            get { return mStrokeBrush; }
            set { mStrokeBrush = value; }
        }

        public TurtleState()
            : this(
                new Point(0, 0),
                new Point(5,5),
                25,
                new SolidColorBrush(Colors.Black)
                )
        {
        }
	

        public TurtleState(Point location, Point orientation, Double deltaAngle,
            Brush strokeBrush)
        {
            mLocation = location;
            mOrientation = orientation;
            mDeltaAngle = deltaAngle;
            mStrokeBrush = strokeBrush;
        }

        public TurtleState Clone()
        {
            return new TurtleState(mLocation, mOrientation, mDeltaAngle, mStrokeBrush);
        }

        //Avanza la localizacion de la tortuga
        public void Advance()
        {
            mLocation = new Point(mLocation.X + mOrientation.X, mLocation.Y + mOrientation.Y);            
        }

        void Rotate(double angleInDegrees)
        {
            double radians = GetRadians(angleInDegrees);
            double x = mOrientation.X * Math.Cos(radians) - mOrientation.Y * Math.Sin(radians);
            double y = mOrientation.Y * Math.Cos(radians) + mOrientation.X * Math.Sin(radians);
            mOrientation = new Point(x, y);
        }

        public void RotateLeft()
        {
            Rotate(mDeltaAngle);
        }

        public void RotateRight()
        {
            Rotate(-mDeltaAngle);
        }

        Double GetRadians(Double grades)
        {
            return (2 * Math.PI * grades) / 360.0;
        }
    }
}
